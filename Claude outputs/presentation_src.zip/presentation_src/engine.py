"""Tiny click-based animation engine on matplotlib + ffmpeg.

A Slide is a list of clicks. Each layer appears on one click (animated with
progress s from 0 to 1) and optionally leaves on a later click (fades out).
Rendering click k draws every layer in its state for that click, so the last
frame of click k is exactly the first frame of click k+1.
"""
import os
import subprocess

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

W, H = 16.0, 9.0            # canvas units
PX_W, PX_H = 1920, 1080
FPS = 30
BG = "#0e1117"

for f in font_manager.findSystemFonts():
    if "Inter" in os.path.basename(f):
        font_manager.fontManager.addfont(f)
plt.rcParams["font.family"] = ["Inter", "DejaVu Sans"]
plt.rcParams["mathtext.fontset"] = "dejavusans"


def ease(s):
    s = max(0.0, min(1.0, s))
    return s * s * (3 - 2 * s)


def seg(s, a, b):
    """Progress of a sub-interval [a, b] of s, eased."""
    if b <= a:
        return 1.0 if s >= b else 0.0
    return ease((s - a) / (b - a))


class Layer:
    def __init__(self, at, fn, until=None, z=0, cut=False):
        self.at, self.fn, self.until, self.z, self.cut = at, fn, until, z, cut


class Slide:
    def __init__(self, sid, name, notes=""):
        self.sid, self.name, self.notes = sid, name, notes
        self.durs = []
        self.layers = []
        self.click_notes = []

    def click(self, dur=1.2, note=""):
        self.durs.append(dur)
        self.click_notes.append(note)
        return len(self.durs) - 1

    def add(self, at, fn, until=None, z=0, cut=False):
        """fn(ax, s, a): s = entrance progress (eased by fn as needed), a = alpha factor."""
        self.layers.append(Layer(at, fn, until, z, cut))

    def state(self, k, fn, z=0, last=False):
        """A layer that exists only during click k (replaced instantly by the next state)."""
        self.add(k, fn, until=None if last else k + 1, z=z, cut=True)

    def draw(self, ax, k, s):
        for L in sorted(self.layers, key=lambda l: l.z):
            if L.at > k:
                continue
            if L.until is not None and L.until < k:
                continue
            if L.until is not None and L.until == k:
                if L.at == k or L.cut:
                    continue
                L.fn(ax, 1.0, 1.0 - ease(s))
            elif L.at == k:
                L.fn(ax, s, 1.0)
            else:
                L.fn(ax, 1.0, 1.0)


def new_fig():
    fig = plt.figure(figsize=(W, H), dpi=PX_W / W)
    ax = fig.add_axes([0, 0, 1, 1])
    return fig, ax


def reset(ax):
    ax.cla()
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.set_facecolor(BG)
    ax.axis("off")
    ax.figure.set_facecolor(BG)


def render_click(slide, k, path, poster=None, last=None):
    fig, ax = new_fig()
    n = max(2, int(round(slide.durs[k] * FPS)))
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgba",
           "-s", f"{PX_W}x{PX_H}", "-r", str(FPS), "-i", "-",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", path]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(n):
        s = i / (n - 1)
        reset(ax)
        slide.draw(ax, k, s)
        fig.canvas.draw()
        buf = fig.canvas.buffer_rgba()
        proc.stdin.write(bytes(buf))
        if i == 0 and poster:
            fig.savefig(poster, facecolor=BG)
        if i == n - 1 and last:
            fig.savefig(last, facecolor=BG)
    proc.stdin.close()
    proc.wait()
    plt.close(fig)
    return n
