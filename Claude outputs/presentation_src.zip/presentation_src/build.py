"""Render every click to MP4 and package the deck.

python3 build.py render   -> media/<slide>_<click>.mp4 + poster/last PNGs
python3 build.py pack     -> out/deck.pptx (one slide per click, video autoplays) + out/handout.pdf
"""
import importlib
import json
import os
import sys
from multiprocessing import Pool

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [ROOT, os.path.join(ROOT, "scenes")]
MEDIA = os.path.join(ROOT, "media")
OUT = os.path.join(ROOT, "out")
SECTIONS = ["s1_problem", "s2_approaches", "s3_evaluation", "s4_wrapup"]


def all_slides():
    out = []
    for m in SECTIONS:
        mod = importlib.import_module(m)
        for f in mod.SLIDES:
            out.append((m, f.__name__))
    return out


def job(args):
    m, fname, k = args
    from engine import render_click
    sl = getattr(importlib.import_module(m), fname)()
    base = os.path.join(MEDIA, f"{fname}_{k + 1:02d}")
    if os.path.exists(base + ".mp4") and os.environ.get("FORCE") != "1":
        return base
    render_click(sl, k, base + ".mp4", poster=base + "_first.png", last=base + "_last.png")
    return base


def manifest():
    rows = []
    for m, fname in all_slides():
        sl = getattr(importlib.import_module(m), fname)()
        for k, d in enumerate(sl.durs):
            rows.append({"module": m, "fn": fname, "sid": sl.sid, "name": sl.name, "click": k + 1,
                         "clicks": len(sl.durs), "dur": d, "notes": sl.notes, "click_note": sl.click_notes[k],
                         "base": os.path.join(MEDIA, f"{fname}_{k + 1:02d}")})
    return rows


def render(only=None):
    os.makedirs(MEDIA, exist_ok=True)
    rows = manifest()
    jobs = [(r["module"], r["fn"], r["click"] - 1) for r in rows if not only or r["fn"] in only]
    with Pool(2) as p:
        for i, b in enumerate(p.imap_unordered(job, jobs)):
            print(f"{i + 1}/{len(jobs)} {os.path.basename(b)}", flush=True)
    json.dump(rows, open(os.path.join(MEDIA, "manifest.json"), "w"), indent=1)


AUTOPLAY = """<p:timing xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:tnLst><p:par><p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst><p:seq concurrent="1" nextAc="seek"><p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst><p:par><p:cTn id="3" fill="hold"><p:stCondLst><p:cond delay="indefinite"/><p:cond evt="onBegin" delay="0"><p:tn val="2"/></p:cond></p:stCondLst><p:childTnLst><p:par><p:cTn id="4" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst><p:par><p:cTn id="5" presetID="1" presetClass="mediacall" presetSubtype="0" fill="hold" nodeType="afterEffect"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst><p:cmd type="call" cmd="playFrom(0.0)"><p:cBhvr><p:cTn id="6" dur="{dur}" fill="hold"/><p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl></p:cBhvr></p:cmd></p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn><p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst><p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst></p:seq><p:video><p:cMediaNode vol="80000"><p:cTn id="7" fill="hold" display="0"><p:stCondLst><p:cond delay="indefinite"/></p:stCondLst></p:cTn><p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl></p:cMediaNode></p:video></p:childTnLst></p:cTn></p:par></p:tnLst></p:timing>"""


def pack():
    from lxml import etree
    from pptx import Presentation
    from pptx.util import Inches
    from pptx.oxml.ns import qn
    from pptx.dml.color import RGBColor
    from PIL import Image

    rows = json.load(open(os.path.join(MEDIA, "manifest.json")))
    os.makedirs(OUT, exist_ok=True)
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    blank = prs.slide_layouts[6]
    for r in rows:
        s = prs.slides.add_slide(blank)
        bg = s.background.fill
        bg.solid()
        bg.fore_color.rgb = RGBColor(0x0E, 0x11, 0x17)
        mv = s.shapes.add_movie(r["base"] + ".mp4", 0, 0, prs.slide_width, prs.slide_height,
                                poster_frame_image=r["base"] + "_first.png", mime_type="video/mp4")
        sld = s._element
        for t in sld.findall(qn("p:timing")):
            sld.remove(t)
        timing = etree.fromstring(AUTOPLAY.format(spid=mv.shape_id, dur=int(r["dur"] * 1000) + 100))
        ext = sld.find(qn("p:extLst"))
        if ext is not None:
            ext.addprevious(timing)
        else:
            sld.append(timing)
        note = f"{r['sid']} {r['name']} · click {r['click']} of {r['clicks']}\n{r['notes']}"
        if r["click_note"]:
            note += f"\nThis click: {r['click_note']}"
        s.notes_slide.notes_text_frame.text = note
    prs.save(os.path.join(OUT, "deck.pptx"))

    # handout: the last frame of the last click of each slide
    last = {}
    for r in rows:
        last[r["fn"]] = r["base"] + "_last.png"
    ims = [Image.open(p).convert("RGB") for p in last.values()]
    ims[0].save(os.path.join(OUT, "handout.pdf"), save_all=True, append_images=ims[1:], resolution=150)
    print("slides:", len(rows), "handout pages:", len(ims))


if __name__ == "__main__":
    if sys.argv[1] == "render":
        render(sys.argv[2:] or None)
    elif sys.argv[1] == "pack":
        pack()
