"""Shared drawing pieces: text, boxes, food icons, the time chart, scoreboards."""
import math

import numpy as np
from matplotlib.patches import Circle, FancyBboxPatch, Polygon, Rectangle, Wedge, Arc
from matplotlib.lines import Line2D

from engine import ease, seg, W, H
import config as C

FG = "#eceff4"
MUTED = "#9aa3b2"
FAINT = "#3a4150"
A_COL = "#a78bfa"     # Approach A purple
B_COL = "#60a5fa"     # Approach B blue
NN_COL = "#9ca3af"    # nearest neighbour grey
BEST = "#f5c542"      # best gold
PATH = "#fb923c"      # rider path orange
OK = "#4ade80"        # on time green
BAD = "#f87171"       # late / cancelled red
AMBER = "#f59e0b"     # deadline tick
WIN = "#6b7280"       # fresh window grey
TEAL = "#2dd4bf"


# ---------- basics ----------
def text(ax, x, y, s, size=18, color=FG, a=1.0, ha="left", va="center", weight="normal", **kw):
    if a <= 0.001:
        return None
    return ax.text(x, y, s, fontsize=size, color=color, alpha=max(0, min(1, a)),
                   ha=ha, va=va, fontweight=weight, **kw)


def box(ax, x0, y0, x1, y1, color=FAINT, a=1.0, fill=None, lw=1.5, r=0.12, fill_a=1.0, z=1):
    if a <= 0.001:
        return
    p = FancyBboxPatch((x0, y0), x1 - x0, y1 - y0, boxstyle=f"round,pad=0,rounding_size={r}",
                       ec=color, fc=fill if fill else "none", lw=lw, alpha=a, zorder=z)
    if fill:
        p.set_facecolor(fill)
        p.set_alpha(a * fill_a)
        ax.add_patch(p)
        p2 = FancyBboxPatch((x0, y0), x1 - x0, y1 - y0, boxstyle=f"round,pad=0,rounding_size={r}",
                            ec=color, fc="none", lw=lw, alpha=a, zorder=z)
        ax.add_patch(p2)
    else:
        ax.add_patch(p)


def line(ax, xs, ys, color=FG, a=1.0, lw=2, ls="-", z=2):
    if a <= 0.001:
        return
    ax.plot(xs, ys, color=color, alpha=a, lw=lw, ls=ls, zorder=z, solid_capstyle="round")


def arrow(ax, x0, y0, x1, y1, color=FG, a=1.0, lw=2, ls="-", head=0.18, z=3):
    if a <= 0.001:
        return
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle=f"-|>,head_length={head*2.2},head_width={head}",
                                color=color, lw=lw, ls=ls, alpha=a, shrinkA=0, shrinkB=0), zorder=z)


def dim(ax, a, level=0.78):
    if a <= 0.001:
        return
    ax.add_patch(Rectangle((0, 0), W, H, fc="#0e1117", ec="none", alpha=level * a, zorder=50))


def check(ax, x, y, ok, a=1.0, r=0.16, z=8):
    if a <= 0.001:
        return
    col = OK if ok else BAD
    ax.add_patch(Circle((x, y), r, fc=col, ec="none", alpha=a, zorder=z))
    text(ax, x, y - 0.01, "✓" if ok else "✕", size=r * 70, color="#0e1117", a=a, ha="center",
         weight="bold", zorder=z + 1, fontfamily="DejaVu Sans")


# ---------- slide furniture ----------
def add_title(slide, title, tag=None):
    def fn(ax, s, a):
        aa = a * seg(s, 0, 0.6)
        text(ax, 0.6, 8.35, title, size=30, weight="bold", a=aa)
        if tag:
            text(ax, 15.4, 8.35, tag, size=14, color=MUTED, a=aa, ha="right")
    slide.add(0, fn)


def add_caption(slide, at, s_text, until=None, color=FG, y=0.55, size=19):
    def fn(ax, s, a):
        text(ax, 8, y, s_text, size=size, color=color, a=a * seg(s, 0.1, 0.7), ha="center", style="italic")
    slide.add(at, fn, until=until, z=20)


def add_overlay(slide, at, lines, until=None, color=FG, size=34):
    def fn(ax, s, a):
        aa = a * seg(s, 0, 0.6)
        dim(ax, aa)
        n = len(lines)
        for i, ln in enumerate(lines):
            text(ax, 8, 4.5 + (n - 1) * 0.45 - i * 0.9, ln, size=size, color=color, a=aa,
                 ha="center", weight="bold", zorder=60)
    slide.add(at, fn, until=until, z=50)


# ---------- food ----------
FOOD_COL = {"ice cream": "#f9a8d4", "noodles": "#fcd34d", "rice": "#f8fafc"}


def food_icon(ax, x, y, food, sc=1.0, a=1.0, z=5):
    if a <= 0.001:
        return
    if food == "ice cream":
        ax.add_patch(Polygon([(x - .2 * sc, y + .02 * sc), (x + .2 * sc, y + .02 * sc), (x, y - .5 * sc)],
                             fc="#d4a373", ec="none", alpha=a, zorder=z))
        ax.add_patch(Circle((x, y + .14 * sc), .21 * sc, fc=FOOD_COL[food], ec="none", alpha=a, zorder=z + 1))
    else:
        ax.add_patch(Wedge((x, y - .05 * sc), .32 * sc, 180, 360, fc="#cbd5e1", ec="none", alpha=a, zorder=z + 1))
        if food == "noodles":
            for i, dx in enumerate((-.14, 0, .14)):
                xs = np.linspace(-.05, .05, 12) * sc
                ys = np.linspace(0, .28, 12) * sc
                ax.plot(x + dx * sc + xs * np.sin(ys * 40), y - .05 * sc + ys, color=FOOD_COL[food],
                        lw=2.2 * sc, alpha=a, zorder=z)
        else:
            ax.add_patch(Wedge((x, y - .05 * sc), .27 * sc, 0, 180, fc=FOOD_COL["rice"], ec="none", alpha=a, zorder=z))


def ring(ax, x, y, r, frac, color, a=1.0, lw=4, z=4):
    if a <= 0.001:
        return
    ax.add_patch(Arc((x, y), 2 * r, 2 * r, theta1=0, theta2=360, color=FAINT, lw=lw, alpha=a, zorder=z))
    frac = max(0.0, min(1.0, frac))
    if frac > 0.002:
        ax.add_patch(Arc((x, y), 2 * r, 2 * r, theta1=90, theta2=90 + 360 * frac, color=color,
                         lw=lw, alpha=a, zorder=z + 1))


# ---------- road view (slide 1.1) ----------
class Road:
    def __init__(self, y=3.9, cx=8.0, sx=0.45):
        self.y, self.cx, self.sx = y, cx, sx

    def X(self, p):
        return self.cx + p * self.sx

    def draw(self, ax, a):
        line(ax, [self.X(-15.5), self.X(15.5)], [self.y, self.y], color="#4b5563", a=a, lw=6, z=1)
        ax.add_patch(Rectangle((self.X(0) - .17, self.y - .17), .34, .34, fc=MUTED, ec="none", alpha=a, zorder=6))
        text(ax, self.X(0), self.y - 0.55, "restaurant", size=13, color=MUTED, a=a, ha="center")
        text(ax, self.X(-15.5), self.y - 0.55, "← west", size=13, color=MUTED, a=a)
        text(ax, self.X(15.5), self.y - 0.55, "east →", size=13, color=MUTED, a=a, ha="right")


# ---------- the time chart ----------
class Chart:
    """Position across (min of driving, restaurant at 0), time running down."""

    def __init__(self, x0=1.6, x1=12.4, ytop=7.0, ybot=1.35, tmax=C.TMAX, pmin=-15, pmax=15,
                 names=None, pos=None, dl=None, label_rows=None, tick=15, font=13):
        self.x0, self.x1, self.ytop, self.ybot, self.tmax = x0, x1, ytop, ybot, tmax
        self.pmin, self.pmax = pmin, pmax
        self.names = names if names is not None else C.NAMES
        self.pos = pos if pos is not None else C.POS
        self.dl = dl if dl is not None else C.DL
        self.label_rows = label_rows or {}
        self.tick, self.font = tick, font

    def X(self, p):
        return self.x0 + (p - self.pmin) / (self.pmax - self.pmin) * (self.x1 - self.x0)

    def Y(self, t):
        return self.ytop - t / self.tmax * (self.ytop - self.ybot)

    def axes(self, ax, a, grow=1.0):
        if a <= 0.001:
            return
        line(ax, [self.x0, self.x1], [self.ytop, self.ytop], color="#4b5563", a=a, lw=4, z=1)
        ybot = self.ytop - grow * (self.ytop - self.ybot)
        line(ax, [self.x0 - 0.2, self.x0 - 0.2], [self.ytop, ybot], color=MUTED, a=a, lw=1.2)
        t = 0
        while t <= self.tmax + 1e-9:
            if self.Y(t) >= ybot - 1e-6:
                line(ax, [self.x0 - 0.2, self.x1], [self.Y(t)] * 2, color="#262c38", a=a, lw=0.8, z=0)
                text(ax, self.x0 - 0.3, self.Y(t), f"{t:g}", size=self.font - 1, color=MUTED, a=a, ha="right")
            t += self.tick
        text(ax, self.x0 - 0.3, self.ybot - 0.4, "min", size=self.font - 1, color=MUTED, a=a * grow, ha="right")
        ax.add_patch(Rectangle((self.X(0) - .13, self.ytop - .13), .26, .26, fc=MUTED, ec="none", alpha=a, zorder=6))
        text(ax, self.x0, self.ybot - 0.4, "← west", size=self.font - 1, color=MUTED, a=a * grow)
        text(ax, self.x1, self.ybot - 0.4, "east →", size=self.font - 1, color=MUTED, a=a * grow, ha="right")
        text(ax, self.X(0), self.ybot - 0.4, "restaurant", size=self.font - 1, color=MUTED, a=a * grow, ha="center")

    def window(self, ax, i, a, s=1.0, color=WIN, label=True, flash=0.0):
        if a <= 0.001:
            return
        x = self.X(self.pos[i])
        d = min(self.dl[i], self.tmax)
        y_end = self.ytop - s * (self.ytop - self.Y(d))
        col = color if flash <= 0 else BAD
        line(ax, [x, x], [self.ytop, y_end], color=col, a=a * (0.9 if flash <= 0 else 0.5 + 0.5 * flash),
             lw=1.6 if flash <= 0 else 3, ls=(0, (3, 3)), z=2)
        if s >= 0.999 and self.dl[i] <= self.tmax:
            line(ax, [x - 0.2, x + 0.2], [self.Y(d)] * 2, color=AMBER, a=a, lw=3.5, z=3)
        if label:
            row = self.label_rows.get(i, 0)
            text(ax, x, self.ytop + 0.32 + 0.38 * row, f"{self.names[i]} {self.dl[i]:g}", size=self.font,
                 color=FG if flash <= 0 else BAD, a=a, ha="center", weight="bold")

    def windows(self, ax, a, s=1.0, ids=None, flash=None):
        ids = range(len(self.pos)) if ids is None else ids
        for i in ids:
            self.window(ax, i, a, s, flash=(flash or {}).get(i, 0.0))

    def verts(self, trace, drive_all=False, start=(0, 0.0)):
        pts = [(self.X(start[0]), self.Y(start[1]))]
        marks = []
        for e in trace:
            if e["ok"] or drive_all:
                pts.append((self.X(self.pos[e["id"]]), self.Y(e["t"])))
                marks.append((len(pts) - 1, e["ok"]))
        return pts, marks

    def path(self, ax, trace, s=1.0, a=1.0, color=PATH, lw=3.2, drive_all=False, dots=True, start=(0, 0.0), z=6):
        if a <= 0.001:
            return
        pts, marks = self.verts(trace, drive_all, start)
        P = np.array(pts)
        if len(P) < 2:
            return
        segl = np.hypot(*(P[1:] - P[:-1]).T)
        cum = np.concatenate([[0], np.cumsum(segl)])
        L = cum[-1] * s
        xs, ys = [P[0, 0]], [P[0, 1]]
        for j in range(1, len(P)):
            if cum[j] <= L:
                xs.append(P[j, 0]); ys.append(P[j, 1])
            else:
                f = (L - cum[j - 1]) / max(segl[j - 1], 1e-9)
                xs.append(P[j - 1, 0] + f * (P[j, 0] - P[j - 1, 0]))
                ys.append(P[j - 1, 1] + f * (P[j, 1] - P[j - 1, 1]))
                break
        ax.plot(xs, ys, color=color, lw=lw, alpha=a, zorder=z, solid_joinstyle="round", solid_capstyle="round")
        if dots:
            for idx, ok in marks:
                if cum[idx] <= L + 1e-9:
                    x, y = P[idx]
                    if ok:
                        ax.add_patch(Circle((x, y), 0.12, fc=OK, ec="none", alpha=a, zorder=z + 1))
                    else:
                        ax.add_patch(Circle((x, y), 0.12, fc="none", ec=BAD, lw=2.5, alpha=a, zorder=z + 1))
        return xs[-1], ys[-1]


def scoreboard(ax, x, y, delivered, total, mean, a=1.0, color=FG, title=None, size=1.0, bad=False):
    if a <= 0.001:
        return
    if title:
        text(ax, x, y + 0.55 * size, title, size=15 * size, color=color, a=a, weight="bold")
    text(ax, x, y, "Delivered", size=14 * size, color=MUTED, a=a)
    text(ax, x, y - 0.45 * size, f"{delivered:g} of {total}", size=24 * size, color=BAD if bad or delivered < total else OK,
         a=a, weight="bold")
    text(ax, x, y - 1.0 * size, "Average wait", size=14 * size, color=MUTED, a=a)
    text(ax, x, y - 1.45 * size, f"{C.fmt(mean)} min", size=24 * size, color=FG, a=a, weight="bold")


def lerp(a, b, s):
    return a + (b - a) * s


# ---------- section / title slides ----------
def section_slide(slide, num, name, sub):
    slide.click(1.2)

    def fn(ax, s, a):
        text(ax, 2.0, 5.0, str(num), size=150, color=A_COL, a=a * seg(s, 0, .5), weight="bold", va="center")
        text(ax, 4.6, 5.45, name, size=54, a=a * seg(s, .2, .7), weight="bold")
        text(ax, 4.65, 4.45, sub, size=24, color=MUTED, a=a * seg(s, .4, .9))
        line(ax, [4.65, 4.65 + 9 * seg(s, .3, 1)], [4.95, 4.95], color=FAINT, a=a, lw=2)
    slide.add(0, fn)
