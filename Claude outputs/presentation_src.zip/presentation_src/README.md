# Presentation source

Click-by-click animated deck built from `slide_flow.md`. Animations are drawn with
matplotlib and encoded with ffmpeg (Manim could not be installed in the build
environment); the output is a PowerPoint file with one slide per click, each
holding a video that plays automatically.

## Files

| Path | What it is |
|---|---|
| `data/solver_out.json` | Every number on screen, exported from the Java solvers by `ExportConfig.java` |
| `data/kl.json` | The 33 Kuala Lumpur locations from `MY.txt` (slide 1.5) |
| `config.py` | Loads the two JSON files |
| `engine.py` | Click engine: layers appear on a click, the last frame of a click = first frame of the next |
| `components.py` | Time chart, food icons, scoreboards, colors |
| `scenes/s1_problem.py` … `s4_wrapup.py` | One function per slide, named as in `slide_flow.md` |
| `build.py` | `render` (MP4 per click) and `pack` (deck.pptx + handout.pdf) |
| `ExportConfig.java` | Put in the solver package next to `SolverA`/`SolverB` to regenerate `solver_out.json` |

Naming: Approach A = plan first, then fix (code `SolverB`); Approach B = one stop
at a time (code `SolverA`).

## Rebuild

Needs Python 3 with matplotlib, numpy, pillow, python-pptx, lxml, and ffmpeg on PATH.

    python3 build.py render            # all clips (about 1.5 min on 2 cores)
    FORCE=1 python3 build.py render slide_2_3_a_moves   # re-render one slide
    python3 build.py pack              # out/deck.pptx and out/handout.pdf

Regenerate the numbers after changing a solver:

    javac -d out com/delivery/routing/*.java
    java -cp out com.delivery.routing.ExportConfig > data/solver_out.json

## Placeholders to fill

- 1.0: group number and member names (`slide_1_0_title`).
- 3.3, 3.4, A.2: results charts wait for the runs on the shared instance files.
- 4.4: AI usage (tools, where, three prompts).
