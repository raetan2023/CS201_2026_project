package com.delivery.routing;
import java.util.*;
/** Exports every number shown in the slides as JSON. Deck naming: Approach A = SolverB (plan + moves), Approach B = SolverA (greedy). */
public class ExportConfig {
  static final double EPS=1e-9;
  static StringBuilder o=new StringBuilder();
  static String f(double d){ return String.format(Locale.ROOT,"%.4f",d); }
  static String trace(DeliveryInstance in,List<Integer> plan){
    StringBuilder s=new StringBuilder("["); int cur=0; double t=0; boolean first=true;
    for(int id:plan){ double a=t+in.travel(cur,id+1); boolean ok=a<=in.customers().get(id).deadline()+EPS;
      if(!first)s.append(","); first=false;
      s.append("{\"id\":"+id+",\"t\":"+f(a)+",\"ok\":"+ok+"}");
      if(ok){t=a;cur=id+1;} }
    return s.append("]").toString();
  }
  static String res(RouteResult r){ return "\"delivered\":"+r.delivered()+",\"mean\":"+f(r.meanWait()); }
  static String plan(List<Integer> p){ return p.toString().replace(" ",""); }
  static String sortFix(DeliveryInstance in){
    List<Integer> p=SolverB.deadlineOrder(in); RouteResult best=SolverB.walk(in,p);
    StringBuilder s=new StringBuilder("{\"start\":{\"plan\":"+plan(p)+",\"trace\":"+trace(in,p)+","+res(best)+"},\"passes\":[");
    boolean first=true;
    while(true){ int n=p.size(); List<Integer> bp=null; int imp=0, bf=-1, bt=-1; RouteResult cur=best;
      for(int a=0;a<n;a++)for(int b=0;b<n;b++){ if(a==b)continue; List<Integer> c=SolverB.move(p,a,b); RouteResult r=SolverB.walk(in,c);
        if(SolverB.isBetter(r,cur))imp++; if(SolverB.isBetter(r,best)){best=r;bp=c;bf=a;bt=b;} }
      if(!first)s.append(","); first=false;
      if(bp==null){ s.append("{\"tried\":"+(n*(n-1))+",\"improving\":0,\"stop\":true}"); break; }
      s.append("{\"tried\":"+(n*(n-1))+",\"improving\":"+imp+",\"moved\":"+p.get(bf)+",\"from\":"+bf+",\"to\":"+bt+",\"plan\":"+plan(bp)+",\"trace\":"+trace(in,bp)+","+res(best)+"}");
      p=bp; }
    return s.append("]}").toString();
  }
  static String greedy(DeliveryInstance in){
    int n=in.size(); boolean[] vis=new boolean[n]; int cur=0; double t=0; StringBuilder s=new StringBuilder("{\"steps\":[");
    boolean first=true;
    while(true){ boolean[] alive=new boolean[n]; for(int v=0;v<n;v++) alive[v]=!vis[v]&&t+in.travel(cur,v+1)<=in.customers().get(v).deadline()+EPS;
      int best=-1,bl=0; double bt=0,bs=0; StringBuilder c=new StringBuilder("["); boolean f1=true;
      for(int u=0;u<n;u++){ if(!alive[u])continue; double tr=in.travel(cur,u+1),arr=t+tr; int lost=0; List<Integer> doom=new ArrayList<>();
        for(int v=0;v<n;v++){ if(!alive[v]||v==u)continue; if(arr+in.travel(u+1,v+1)>in.customers().get(v).deadline()+EPS){lost++;doom.add(v);} }
        double sl=in.customers().get(u).deadline()-arr;
        if(!f1)c.append(","); f1=false;
        c.append("{\"id\":"+u+",\"arr\":"+f(arr)+",\"lost\":"+lost+",\"doom\":"+doom.toString().replace(" ","")+",\"travel\":"+f(tr)+",\"slack\":"+f(sl)+"}");
        boolean better = best==-1 || lost<bl || (lost==bl && (tr<bt-EPS || (Math.abs(tr-bt)<=EPS && (sl<bs-EPS || (Math.abs(sl-bs)<=EPS && u<best)))));
        if(better){best=u;bl=lost;bt=tr;bs=sl;} }
      c.append("]");
      if(best<0)break;
      if(!first)s.append(","); first=false;
      s.append("{\"t\":"+f(t)+",\"at\":"+(cur-1)+",\"cands\":"+c+",\"chosen\":"+best+"}");
      vis[best]=true; t+=bt; cur=best+1; }
    RouteResult r=new SolverA().solve(in);
    StringBuilder tr=new StringBuilder("["); for(int k=0;k<r.route().size();k++){ if(k>0)tr.append(","); tr.append("{\"id\":"+r.route().get(k)+",\"t\":"+f(r.arrivals().get(k))+",\"ok\":true}"); }
    return s.append("],\"trace\":"+tr+"],\"dropped\":"+r.dropped().toString().replace(" ","")+","+res(r)+"}").toString();
  }
  static String nnDrive(DeliveryInstance in){
    int n=in.size(); boolean[] vis=new boolean[n]; int cur=0; double t=0; StringBuilder s=new StringBuilder("["); int del=0; double w=0;
    for(int k=0;k<n;k++){ int b=-1; double bd=1e18; for(int v=0;v<n;v++){ if(vis[v])continue; double d=in.travel(cur,v+1); if(d<bd){bd=d;b=v;} }
      vis[b]=true; t+=bd; cur=b+1; boolean ok=t<=in.customers().get(b).deadline()+EPS; if(ok){del++;w+=t-in.customers().get(b).orderTime();}
      if(k>0)s.append(","); s.append("{\"id\":"+b+",\"t\":"+f(t)+",\"ok\":"+ok+"}"); }
    return "{\"trace\":"+s+"],\"delivered\":"+del+",\"mean\":"+f(del==0?0:w/del)+"}";
  }
  static String inst(String[] names,double[] pos,double[] dl,String[] food){
    StringBuilder s=new StringBuilder("[");
    for(int i=0;i<names.length;i++){ if(i>0)s.append(","); s.append("{\"id\":"+i+",\"name\":\""+names[i]+"\",\"pos\":"+f(pos[i])+",\"deadline\":"+f(dl[i])+",\"food\":\""+food[i]+"\"}"); }
    return s.append("]").toString();
  }
  static List<List<Integer>> perms(int n){ List<List<Integer>> out=new ArrayList<>(); perm(new ArrayList<>(),new boolean[n],n,out); return out; }
  static void perm(List<Integer> c,boolean[] u,int n,List<List<Integer>> out){ if(c.size()==n){out.add(new ArrayList<>(c));return;} for(int i=0;i<n;i++){ if(u[i])continue; u[i]=true;c.add(i);perm(c,u,n,out);c.remove(c.size()-1);u[i]=false; } }
  static String brute(DeliveryInstance in){ return brute(in,true); }
  static String brute(DeliveryInstance in,boolean withPerms){
    StringBuilder s=new StringBuilder("["); boolean first=true; RouteResult best=null; List<Integer> bp=null;
    for(List<Integer> p:perms(in.size())){ RouteResult r=SolverB.walk(in,p); if(!first)s.append(","); first=false;
      s.append("{\"plan\":"+plan(p)+","+res(r)+"}"); if(best==null||SolverB.isBetter(r,best)){best=r;bp=p;} }
    return "{"+(withPerms?"\"perms\":"+s+"],":"")+"\"bestPlan\":"+plan(bp)+",\"best\":{"+res(best)+",\"trace\":"+trace(in,bp)+"}}";
  }
  static String example(String key,String[] names,double[] pos,double[] dl,String[] food,boolean full){
    DeliveryInstance in=Demo.lineInstance(pos,dl,food);
    StringBuilder s=new StringBuilder("\""+key+"\":{\"customers\":"+inst(names,pos,dl,food));
    s.append(",\"approachA\":"+sortFix(in)+",\"approachB\":"+greedy(in));
    if(full){ s.append(",\"nn\":"+nnDrive(in)); List<Integer> idp=new ArrayList<>(); for(int i=0;i<pos.length;i++)idp.add(i);
      RouteResult r=SolverB.walk(in,idp); s.append(",\"idOrder\":{\"plan\":"+plan(idp)+",\"trace\":"+trace(in,idp)+","+res(r)+"}"); s.append(",\"brute\":"+brute(in)); }
    else { s.append(",\"brute\":"+brute(in,false)); }
    return s.append("}").toString();
  }
  public static void main(String[] a){
    o.append("{");
    o.append(example("running",new String[]{"Amy","Ben","Cat","Dan","Eve"},new double[]{9,-13,8,-7,14},new double[]{30,60,60,90,30},new String[]{"ice cream","noodles","noodles","rice","ice cream"},true)).append(",");
    o.append(example("pqr",new String[]{"P","Q","R"},new double[]{5,-5,-1},new double[]{10,16,90},new String[]{"","","rice"},false)).append(",");
    o.append(example("stuv",new String[]{"S","T","U","V"},new double[]{-5,5,-12,4},new double[]{16,31,24,20},new String[]{"","","",""},false));
    o.append("}");
    System.out.println(o);
  }
}
