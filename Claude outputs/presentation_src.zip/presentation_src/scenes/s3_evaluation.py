"""Section 3: Evaluation."""
from matplotlib.patches import Rectangle

from engine import Slide, seg, ease
from components import *
import config as C

RUN = C.RUN
N = len(C.NAMES)
AA, BB, NNR = RUN["approachA"], RUN["approachB"], RUN["nn"]


def slide_3_0_section():
    sl = Slide("3.0", "section", "Section 3: evaluation.")
    section_slide(sl, 3, "Evaluation", "Who wins, when, and why")
    return sl


def final_A():
    ps = [p for p in AA["passes"] if not p.get("stop")]
    return ps[-1] if ps else AA["start"]


def slide_3_1_head_to_head():
    sl = Slide("3.1", "head to head", "Point: on this example Approach A finds the true best.")
    add_title(sl, "Head to head on the running example", "3.1")
    for d in (2.6, 2.6, 1.8):
        sl.click(d)
    fa = final_A()
    panels = [("Nearest neighbour", NN_COL, NNR["trace"], True, NNR["delivered"], NNR["mean"]),
              ("Approach B", B_COL, BB["trace"], False, BB["delivered"], BB["mean"]),
              ("Approach A", A_COL, fa["trace"], False, fa["delivered"], fa["mean"])]
    charts = [Chart(x0=x0, x1=x0 + 4.0, ytop=6.15, ybot=3.65, tick=30, font=10, label_rows={2: 1})
              for x0 in (1.0, 6.1, 11.2)]

    def c1(ax, s, a):
        for j, (ch, (nm, col, tr, da, d, m)) in enumerate(zip(charts, panels)):
            f = seg(s, j * .2, j * .2 + .3)
            ch.axes(ax, a * f)
            ch.windows(ax, a * f)
            ch.path(ax, tr, s=seg(s, j * .2 + .2, j * .2 + .55), a=a, color=col, drive_all=da, lw=2.6)
            fs = seg(s, j * .2 + .5, j * .2 + .65)
            text(ax, ch.x0, 7.55, nm, size=16, weight="bold", color=col, a=a * f)
            text(ax, ch.x1, 7.55, f"{d} of {N} · {C.fmt(m)} min", size=15, ha="right",
                 color=OK if d == N else BAD, a=a * fs, weight="bold")
    sl.add(0, c1)
    perms = RUN["brute"]["perms"]
    best_plan = RUN["brute"]["bestPlan"]
    cols, size, step = 24, .26, .32
    gx0 = 8 - cols * step / 2

    def sq(j):
        return gx0 + (j % cols) * step, 2.65 - (j // cols) * step

    n_all = sum(1 for p in perms if p["delivered"] == N)

    def grid(ax, s, a, phase):
        for j, p in enumerate(perms):
            x, y = sq(j)
            if phase == 0:
                f = seg(s, .5 * j / len(perms), .5 * j / len(perms) + .1)
                g = seg(s, .6, .85)
                full = p["delivered"] == N
                col = OK if full or g < .5 else "#2b313c"
                aa = a * f
            else:
                full = p["delivered"] == N
                isbest = p["plan"] == best_plan
                g = seg(s, .1, .5)
                if isbest:
                    col = BEST
                elif full:
                    col = OK if g < .5 else "#1f4a32"
                else:
                    col = "#2b313c"
                aa = a
            ax.add_patch(Rectangle((x, y), size, size, fc=col, ec="none", alpha=aa, zorder=4))
        text(ax, gx0 - .25, 2.2, f"{len(perms)} visiting\norders", size=14, ha="right", color=MUTED,
             a=a * (seg(s, 0, .15) if phase == 0 else 1))
        if phase == 1:
            text(ax, gx0 + cols * step + .15, 2.35, f"{n_all} deliver\nall five", size=14, color=OK, a=a * (1 - seg(s, 0, .3)))
        if phase == 0:
            text(ax, gx0 + cols * step + .15, 2.35, f"{n_all} deliver\nall five", size=14, color=OK, a=a * seg(s, .8, 1))
    sl.state(1, lambda ax, s, a: grid(ax, s, a, 0))

    def c3(ax, s, a):
        grid(ax, s, a, 1)
        j = [i for i, p in enumerate(perms) if p["plan"] == best_plan][0]
        x, y = sq(j)
        best = RUN["brute"]["best"]
        text(ax, gx0 + cols * step + .15, 2.35, f"best: {C.fmt(best['mean'])} min", size=15, color=BEST,
             weight="bold", a=a * seg(s, .45, .7))
        f = seg(s, .5, .8)
        box(ax, 10.75, 3.05, 15.45, 7.95, color=BEST, a=a * f, lw=2.5, r=.15)
        box(ax, x - .05, y - .05, x + size + .05, y + size + .05, color=BEST, a=a * f, lw=2, r=.02)
    sl.state(2, c3, last=True)
    add_caption(sl, 2, "All 120 orders checked: A's answer is the best possible here.")
    return sl


def _trap_chart(d, x0, tmax, pmin, pmax, tick, rows):
    cs = d["customers"]
    return Chart(x0=x0, x1=x0 + 5.6, ytop=6.3, ybot=2.75, tmax=tmax, pmin=pmin, pmax=pmax,
                 names=[c["name"] for c in cs], pos=[c["pos"] for c in cs], dl=[c["deadline"] for c in cs],
                 tick=tick, font=12, label_rows=rows)


def slide_3_2_traps():
    sl = Slide("3.2", "traps", "Point: the two approaches fail on opposite structures.")
    add_title(sl, "Each approach's trap", "3.2")
    for d in (2.2, 2.0, 2.2, 2.0, 1.0):
        sl.click(d)
    P, S = C.PQR, C.STUV
    L = _trap_chart(P, 1.4, 20, -6, 6, 5, {})
    R = _trap_chart(S, 9.6, 32, -13, 6, 8, {3: 1})
    nm = lambda d, i: d["customers"][i]["name"]

    def last(d):
        ps = [p for p in d["approachA"]["passes"] if not p.get("stop")]
        return ps[-1] if ps else d["approachA"]["start"]
    pA, sA = last(P), last(S)
    pB, sB = P["approachB"], S["approachB"]

    sl.add(0, lambda ax, s, a: (L.axes(ax, a * seg(s, 0, .3)), L.windows(ax, a * seg(s, 0, .3)),
                                text(ax, 1.4, 7.55, ", ".join(c["name"] for c in P["customers"]), size=18,
                                     weight="bold", a=a * seg(s, 0, .3))))
    first = nm(P, pB["trace"][0]["id"])
    lost = ", ".join(nm(P, i) for i in pB["dropped"])
    sl.add(0, lambda ax, s, a: (L.path(ax, pB["trace"], s=seg(s, .3, .8), a=a, color=B_COL),
                                text(ax, 1.4, 1.95, f"B: {first} first (‘looks safe’), then {lost} is lost: "
                                     f"{pB['delivered']} of {len(P['customers'])}", size=14, color=B_COL,
                                     a=a * seg(s, .7, 1))))
    sl.add(1, lambda ax, s, a: (L.path(ax, pA["trace"], s=seg(s, 0, .7), a=a, color=A_COL, lw=2.6),
                                text(ax, 1.4, 1.45, "A: " + ", ".join(f"{nm(P, e['id'])} {e['t']:g}" for e in pA["trace"] if e["ok"])
                                     + f": {pA['delivered']} of {len(P['customers'])}, avg {C.fmt(pA['mean'])}",
                                     size=14, color=A_COL, a=a * seg(s, .6, 1))))
    lostA = ", ".join(nm(S, e["id"]) for e in sA["trace"] if not e["ok"])
    sl.add(2, lambda ax, s, a: (R.axes(ax, a * seg(s, 0, .3)), R.windows(ax, a * seg(s, 0, .3)),
                                text(ax, 9.6, 7.55, ", ".join(c["name"] for c in S["customers"]), size=18,
                                     weight="bold", a=a * seg(s, 0, .3)),
                                R.path(ax, sA["trace"], s=seg(s, .3, .8), a=a, color=A_COL),
                                text(ax, 9.6, 1.95, f"A: deadline order loses {lostA}; no single move helps: "
                                     f"{sA['delivered']} of {len(S['customers'])}", size=14, color=A_COL,
                                     a=a * seg(s, .7, 1))))
    sl.add(3, lambda ax, s, a: (R.path(ax, sB["trace"], s=seg(s, 0, .7), a=a, color=B_COL, lw=2.6),
                                text(ax, 9.6, 1.45, "B: " + ", ".join(f"{nm(S, e['id'])} {e['t']:g}" for e in sB["trace"])
                                     + f": {sB['delivered']} of {len(S['customers'])}", size=14, color=B_COL,
                                     a=a * seg(s, .6, 1))))
    add_caption(sl, 4, "B checks orders one at a time. A changes the plan one stop at a time.")
    return sl


def placeholder_panel(ax, a, x0, y0, x1, y1, title, ylab, xlab, legend=None):
    box(ax, x0, y0, x1, y1, color=FAINT, a=a, fill="#131820")
    text(ax, x0 + .25, y1 - .35, title, size=15, weight="bold", a=a)
    line(ax, [x0 + .8, x0 + .8], [y0 + .6, y1 - .75], color=MUTED, a=a, lw=1)
    line(ax, [x0 + .8, x1 - .3], [y0 + .6, y0 + .6], color=MUTED, a=a, lw=1)
    text(ax, (x0 + x1) / 2, y0 + .3, xlab, size=12, color=MUTED, ha="center", a=a)
    text(ax, x0 + .25, y1 - .75, ylab, size=11, color=MUTED, a=a)
    text(ax, (x0 + x1) / 2 + .2, (y0 + y1) / 2, "awaiting runs on the\nshared instance files", size=14,
         color="#4b5563", ha="center", a=a, style="italic")
    if legend:
        for j, (lb, col) in enumerate(legend):
            box(ax, x1 - 2.2, y1 - .5 - j * .35, x1 - 2.0, y1 - .3 - j * .35, color=col, fill=col, a=a, r=.02)
            text(ax, x1 - 1.9, y1 - .4 - j * .35, lb, size=11, a=a)


LEG = [("Nearest neighbour", NN_COL), ("Approach B", B_COL), ("Approach A", A_COL), ("Best (n ≤ 10)", BEST)]


def slide_3_3_results_cancelled():
    sl = Slide("3.3", "results cancelled", "TODO: fill from results/summary.csv after the shared-instance runs.")
    add_title(sl, "Results: orders cancelled", "3.3")
    for d in (1.2, 1.2, 1.2):
        sl.click(d)
    sl.add(0, lambda ax, s, a: placeholder_panel(ax, a * seg(s, 0, .6), .6, 1.2, 8.6, 7.7,
                                                 "Tightness 1.0", "avg cancelled (30 seeds)", "n = 5, 8, 10, 20, 50, 100", LEG))
    sl.add(1, lambda ax, s, a: (placeholder_panel(ax, a * seg(s, 0, .6), 8.9, 4.6, 12.2, 7.7, "Tightness 0.5", "", "n"),
                                placeholder_panel(ax, a * seg(s, .2, .8), 12.4, 4.6, 15.7, 7.7, "Tightness 1.5", "", "n")))
    sl.add(2, lambda ax, s, a: placeholder_panel(ax, a * seg(s, 0, .6), 8.9, 1.2, 15.7, 4.3,
                                                 "Gap to brute force, n ≤ 10", "extra cancelled", "V1 and V2"))
    return sl


def slide_3_4_results_speed():
    sl = Slide("3.4", "results speed", "TODO: fill run times after the shared-instance runs.")
    add_title(sl, "Results: speed", "3.4")
    sl.click(1.2)
    sl.click(1.0)
    sl.add(0, lambda ax, s, a: placeholder_panel(ax, a * seg(s, 0, .6), 2.0, 1.3, 14.0, 7.7, "Run time vs n",
                                                 "ms (log scale)", "n = 5 … 100", LEG[1:3]))
    add_caption(sl, 1, "Expected: A pays for its fixes in time; B stays near-instant. (Check against the real runs.)")
    return sl


ROWS3 = [("Idea", "Full plan, then improve", "One stop at a time"),
         ("Data structure", "List of all n customers", "visited[ ] / alive[ ] arrays"),
         ("Time", "O(n log n) + O(n³) per pass × passes", "O(n³), fixed"),
         ("Space", "O(n)", "O(n)"),
         ("Undo a choice / revive a cancel", "Yes / yes", "No / no"),
         ("Trap", "Needs two moves at once", "Checks orders one at a time")]


def slide_3_5_tradeoffs():
    sl = Slide("3.5", "tradeoffs", "One row per click.")
    add_title(sl, "Complexity and trade-offs", "3.5")
    for _ in ROWS3:
        sl.click(1.0)

    def head(ax, s, a):
        aa = a * seg(s, 0, .5)
        text(ax, 5.3, 7.35, "Approach A", size=20, weight="bold", color=A_COL, a=aa)
        text(ax, 10.8, 7.35, "Approach B", size=20, weight="bold", color=B_COL, a=aa)
        line(ax, [.7, 15.4], [6.95, 6.95], color=FAINT, a=aa, lw=1.2)
    sl.add(0, head)
    for r, (k, va, vb) in enumerate(ROWS3):
        y = 6.4 - r * .95

        def fn(ax, s, a, y=y, k=k, va=va, vb=vb):
            aa = a * seg(s, 0, .6)
            text(ax, .8, y, k, size=16, color=MUTED, a=aa)
            text(ax, 5.3, y, va, size=17, a=aa)
            text(ax, 10.8, y, vb, size=17, a=aa)
            line(ax, [.7, 15.4], [y - .47, y - .47], color="#1d222c", a=aa, lw=1)
        sl.add(r, fn)
    return sl


SLIDES = [slide_3_0_section, slide_3_1_head_to_head, slide_3_2_traps, slide_3_3_results_cancelled,
          slide_3_4_results_speed, slide_3_5_tradeoffs]
