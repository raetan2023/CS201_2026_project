"""Section 1: Problem."""
import math

import numpy as np
from matplotlib.patches import Circle, Rectangle

from engine import Slide, seg, ease
from components import *
import config as C

RUN = C.RUN
N = len(C.NAMES)


def slide_1_0_title():
    sl = Slide("1.0", "title", "Title. Introduce the group and the topic in one sentence.")
    sl.click(1.6)

    def fn(ax, s, a):
        text(ax, 8, 5.6, "Food Before It Spoils", size=62, weight="bold", ha="center", a=a * seg(s, 0, .5))
        text(ax, 8, 4.55, "Redesigning the TSP for deadline-aware delivery", size=26, color=MUTED, ha="center",
             a=a * seg(s, .2, .7))
        line(ax, [8 - 4 * seg(s, .3, 1), 8 + 4 * seg(s, .3, 1)], [4.0, 4.0], color=FAINT, lw=2, a=a)
        text(ax, 8, 3.3, "CS201 · Group [XX]", size=20, ha="center", a=a * seg(s, .5, 1))
        text(ax, 8, 2.75, "[Member names]", size=18, color=MUTED, ha="center", a=a * seg(s, .5, 1))
        for i, f in enumerate(["ice cream", "noodles", "rice"]):
            food_icon(ax, 7.0 + i, 7.1, f, sc=0.9, a=a * seg(s, .4 + .1 * i, .8 + .1 * i))
    sl.add(0, fn)
    return sl


def slide_1_0_section():
    sl = Slide("1.0s", "section", "Section 1: the problem.")
    section_slide(sl, 1, "Problem", "One rider, five orders, three shelf lives")
    return sl


# ---------- 1.1 hook ----------
ROAD = Road()
ICON_Y = {i: 5.25 for i in range(N)}
ICON_Y[2] = 6.95                       # Cat sits above Amy (they are 1 min apart)
NN = RUN["nn"]["trace"]


def nn_pos(t):
    """Rider position at time t along the nearest-neighbour drive (drives to everyone)."""
    p0, t0 = 0.0, 0.0
    for e in NN:
        p1, t1 = C.POS[e["id"]], e["t"]
        if t <= t1:
            f = 0 if t1 == t0 else (t - t0) / (t1 - t0)
            return p0 + f * (p1 - p0)
        p0, t0 = p1, t1
    return p0


def ring_col(frac):
    return OK if frac > .5 else (AMBER if frac > .2 else BAD)


def customers(ax, a, t=0.0, rings=False, arrivals=None, badges=True, ring_a=1.0):
    """Icons on the road view. arrivals: {id: (t, ok)} — rings freeze at delivery."""
    for i in range(N):
        x, y = ROAD.X(C.POS[i]), ICON_Y[i]
        line(ax, [x, x], [ROAD.y + 0.18, y - 0.62], color=FAINT, a=a, lw=1.2, ls=(0, (2, 3)))
        food_icon(ax, x, y, C.FOOD[i], sc=0.85, a=a)
        if i == 2:
            text(ax, x - 0.75, y, C.NAMES[i], size=17, a=a, ha="right", weight="bold")
        else:
            text(ax, x, y + 0.82, C.NAMES[i], size=17, a=a, ha="center", weight="bold")
        if rings:
            tt = t
            if arrivals and i in arrivals and arrivals[i][0] <= t:
                tt = arrivals[i][0]
            frac = 1 - tt / C.DL[i]
            ring(ax, x, y - .08, .55, frac, ring_col(frac), a=a * ring_a)
        if badges and arrivals and i in arrivals and arrivals[i][0] <= t:
            check(ax, x + .45, y + .42, arrivals[i][1], a=a)


def slide_1_1_hook():
    sl = Slide("1.1", "hook", "Point: a route can look efficient and still fail customers.")
    add_title(sl, "The closest stop is not the right stop", "1.1")
    for d, n in [(1.4, "Road, restaurant, five customers."), (3.2, "Countdown rings: ice cream 30, noodles 60, rice 90."),
                 (5.0, "Nearest neighbour drives: both ice creams melt."), (1.0, "Scoreboard: 3 of 5, 18.0 min."),
                 (1.0, "Question: what does better even mean?")]:
        sl.click(d, n)
    arr = {e["id"]: (e["t"], e["ok"]) for e in NN}
    tend = NN[-1]["t"]

    def c1(ax, s, a):
        ROAD.draw(ax, a * seg(s, 0, .4))
        customers(ax, a * seg(s, .3, .9))
    sl.state(0, c1)
    add_caption(sl, 0, "One rider. Five orders. One trip.", until=1)

    def c2(ax, s, a):
        ROAD.draw(ax, a)
        t = 30 * seg(s, 0, .75) * (1 - seg(s, .82, 1)) if s < 1 else 0
        customers(ax, a, t=t, rings=True, badges=False, ring_a=seg(s, 0, .12))
        if 0.02 < s < 0.82:
            text(ax, 15.4, 2.3, f"t = {30 * seg(s, 0, .75):.0f} min", size=20, ha="right", color=MUTED, a=a)
    sl.state(1, c2)
    add_caption(sl, 1, "Ice cream lasts 30 min, noodles 60, rice 90.", until=2)

    def drive(ax, s, a, t, fin=1.0):
        ROAD.draw(ax, a)
        customers(ax, a, t=t, rings=True, arrivals=arr)
        p = nn_pos(t)
        ax.add_patch(Circle((ROAD.X(p), ROAD.y), .2, fc=NN_COL, ec="white", lw=1.5, alpha=a * fin, zorder=9))
        text(ax, 15.4, 2.3, f"t = {t:.0f} min", size=20, ha="right", color=MUTED, a=a * fin)

    sl.state(2, lambda ax, s, a: drive(ax, s, a, tend * seg(s, 0.05, 0.95), fin=seg(s, 0, .05)))
    add_caption(sl, 2, "Always go to the closest: both ice creams melt.", until=3)
    for k in (3, 4):
        sl.state(k, lambda ax, s, a: drive(ax, s, a, tend), last=(k == 4))

    def score(ax, s, a):
        aa = a * seg(s, 0, .6)
        text(ax, 5.2, 2.15, f"Delivered {RUN['nn']['delivered']} of {N}", size=30, color=BAD, ha="center", weight="bold", a=aa)
        text(ax, 10.8, 2.15, f"Average wait {C.fmt(RUN['nn']['mean'])} min", size=30, color=OK, ha="center", weight="bold", a=aa)
    sl.add(3, score)
    add_caption(sl, 3, "And yet its average wait looks great.", until=4)
    add_overlay(sl, 4, ["What does a ‘better’ route even mean?"])
    return sl


# ---------- 1.2 classic TSP ----------
PTS = [(1.7, 6.5), (3.3, 2.1), (6.3, 6.7), (6.6, 2.7), (1.4, 3.6)]
R0 = (4.0, 4.4)
TOUR = [R0, PTS[2], PTS[3], PTS[1], PTS[4], PTS[0], R0]
ROWS = [("Every city equally important", "Each order has a deadline"),
        ("Only the visit order matters", "Arrival time matters"),
        ("Must visit every city", "Cancel orders that\ncan't be on time"),
        ("Tour returns to the start", "Route ends at the\nlast customer"),
        ("Goal: shortest distance", "Goal: most on time,\nthen least wait")]


def slide_1_2_classic_tsp():
    sl = Slide("1.2", "classic TSP", "Point: five classic assumptions break; one change per click.")
    add_title(sl, "Why the classic TSP is not enough", "1.2")
    for d in (2.0, 1.4, 1.4, 1.2, 1.2, 1.4, 1.0):
        sl.click(d)

    def tour(ax, s, a, upto=6, close_a=1.0):
        segs = len(TOUR) - 1
        for j in range(segs):
            f = seg(s, j / segs, (j + 1) / segs)
            if f <= 0:
                break
            (x0, y0), (x1, y1) = TOUR[j], TOUR[j + 1]
            aa = a * (close_a if j == segs - 1 else 1)
            line(ax, [x0, x0 + f * (x1 - x0)], [y0, y0 + f * (y1 - y0)], color=PATH, a=aa, lw=3)

    def dots(ax, a, grey=None):
        ax.add_patch(Rectangle((R0[0] - .15, R0[1] - .15), .3, .3, fc=MUTED, ec="none", alpha=a, zorder=6))
        for i, (x, y) in enumerate(PTS):
            col = "#4b5563" if grey == i else FG
            ax.add_patch(Circle((x, y), .16, fc=col, ec="none", alpha=a, zorder=7))

    # left diagram
    sl.add(0, lambda ax, s, a: tour(ax, s, a), until=4, cut=True)
    sl.add(4, lambda ax, s, a: tour(ax, 1, a, close_a=1 - ease(s)), until=5, cut=True)
    sl.add(5, lambda ax, s, a: tour(ax, 1, a, close_a=0))
    sl.add(0, lambda ax, s, a: dots(ax, a * seg(s, 0, .3)), until=3, cut=True)
    sl.add(3, lambda ax, s, a: (dots(ax, a, grey=0), ax.add_patch(Circle(PTS[0], .16, fc=FG, ec="none", alpha=a * (1 - seg(s, 0, .5)), zorder=8)), check(ax, PTS[0][0] + .3, PTS[0][1] + .3, False, a=a * seg(s, 0, .6))))
    fr = [.75, .35, .6, .45, .9]
    sl.add(1, lambda ax, s, a: [ring(ax, x, y, .36, fr[i] * seg(s, 0, 1), ring_col(fr[i]), a=a * seg(s, 0, .2), lw=3)
                                for i, (x, y) in enumerate(PTS)])
    km = ["3.2 km", "4.0 km", "3.4 km", "2.0 km", "2.9 km", "3.1 km"]
    mins = ["t = 10", "t = 22", "t = 32", "t = 38", "t = 47", ""]

    def edge_labels(ax, s, a, labels):
        for j in range(len(TOUR) - 1):
            if not labels[j]:
                continue
            (x0, y0), (x1, y1) = TOUR[j], TOUR[j + 1]
            text(ax, (x0 + x1) / 2 + .15, (y0 + y1) / 2 + .2, labels[j], size=12, color=MUTED, a=a)
    sl.add(0, lambda ax, s, a: edge_labels(ax, s, a * seg(s, .7, 1), km), until=2)
    sl.add(2, lambda ax, s, a: edge_labels(ax, s, a * seg(s, .3, 1), mins))
    sl.add(0, lambda ax, s, a: text(ax, 4.0, 1.15, "Goal: shortest distance", size=16, ha="center", color=MUTED,
                                    a=a * seg(s, .7, 1)), until=5)
    sl.add(5, lambda ax, s, a: text(ax, 4.0, 1.15, "Goal: most on time, then least wait", size=16, ha="center",
                                    color=OK, a=a * seg(s, .3, 1)))

    # right table
    def header(ax, s, a):
        aa = a * seg(s, .5, 1)
        text(ax, 8.0, 7.35, "Classic TSP", size=17, color=MUTED, a=aa, weight="bold")
        text(ax, 11.9, 7.35, "Our use case", size=17, color=OK, a=aa, weight="bold")
        line(ax, [7.9, 15.6], [7.0, 7.0], color=FAINT, a=aa, lw=1.2)
    sl.add(0, header)
    for r, (l, rt) in enumerate(ROWS):
        y = 6.35 - r * 1.05

        def row(ax, s, a, y=y, l=l, rt=rt):
            aa = a * seg(s, 0, .6)
            text(ax, 8.0, y, l, size=15, color=MUTED, a=aa)
            text(ax, 11.45, y, "→", size=16, color=MUTED, a=aa)
            text(ax, 11.9, y, rt, size=15, a=aa, linespacing=1.2)
        sl.add(r + 1, row)
    add_caption(sl, 0, "Classic TSP: shortest closed tour, every city once.", until=1)
    add_caption(sl, 6, "The Minimum Latency Problem with deadlines: NP-hard. We redesign heuristics.")
    return sl


# ---------- 1.3 the new problem ----------
def slide_1_3_variant():
    sl = Slide("1.3", "variant", "Point: input, output, rules; goals compared in order.")
    add_title(sl, "The new problem", "1.3")
    for d in (1.0, 1.0, 1.2, 1.2, 1.4, 1.0):
        sl.click(d)

    def panel(k, x0, y0, x1, y1, head, lines, col=FG, size=15, gap=0.5):
        def fn(ax, s, a):
            aa = a * seg(s, 0, .6)
            box(ax, x0, y0, x1, y1, color=FAINT, a=aa, fill="#151a23")
            text(ax, x0 + .3, y1 - .4, head, size=18, weight="bold", color=col, a=aa)
            for i, ln in enumerate(lines):
                text(ax, x0 + .3, y1 - 1.0 - i * gap, ln, size=size, a=aa * seg(s, .2 + .1 * i, .6 + .1 * i))
        sl.add(k, fn)
    panel(0, .6, 4.6, 5.4, 7.7, "Input (known at t = 0)", ["Restaurant + n orders", "Travel time w(i, j), minutes",
                                                          "Order time o, food, shelf life ℓ", "Rider leaves at t = 0"])
    panel(1, 5.7, 4.6, 10.3, 7.7, "Output", ["The order the rider visits", "customers in.", "Anyone left out is cancelled."])
    panel(2, 10.6, 4.6, 15.4, 7.7, "Rules", ["One rider, never returns", "No time spent at the door",
                                           "Wait = arrival a − order time o", "Late = 0, always"])

    def dl_table(ax, s, a):
        aa = a * seg(s, 0, .6)
        box(ax, .6, 1.3, 7.4, 4.2, color=FAINT, a=aa, fill="#151a23")
        text(ax, .9, 3.8, "Deadline d", size=18, weight="bold", a=aa)
        text(ax, .9, 3.0, "V1", size=17, weight="bold", color=MUTED, a=aa)
        text(ax, 1.9, 3.0, "d = o + ℓ", size=17, a=aa)
        text(ax, 4.3, 3.0, "food must not spoil", size=14, color=MUTED, a=aa)
        text(ax, .9, 2.1, "V2", size=17, weight="bold", color=MUTED, a=aa)
        text(ax, 1.9, 2.1, "d = o + min(ℓ, 60)", size=17, a=aa)
        box(ax, 2.88, 1.8, 4.95, 2.4, color=AMBER, a=aa * seg(s, .5, 1), lw=2)
        text(ax, 1.9, 1.55, "no one waits more than an hour", size=13, color=MUTED, a=aa)
    sl.add(3, dl_table)
    add_caption(sl, 3, "V2: no one waits more than an hour.", until=4)

    def goals(ax, s, a):
        aa = a * seg(s, 0, .5)
        box(ax, 7.8, 1.3, 15.4, 4.2, color=OK, a=aa, fill="#151a23")
        text(ax, 8.1, 3.8, "Goals, in this order", size=18, weight="bold", color=OK, a=aa)
        text(ax, 8.1, 3.0, "1. Fewest cancelled", size=24, weight="bold", a=aa)
        text(ax, 8.1, 2.2, "2. Lowest average wait", size=17, a=aa)
        aa2 = a * seg(s, .45, 1)
        box(ax, 12.6, 1.6, 15.1, 3.3, color=FAINT, a=aa2, fill="#0e1117")
        text(ax, 12.85, 3.0, "Nearest neighbour", size=12, color=MUTED, a=aa2)
        text(ax, 12.85, 2.45, f"{RUN['nn']['delivered']} of {N}", size=22, color=BAD, weight="bold", a=aa2)
        text(ax, 12.85, 1.9, f"{C.fmt(RUN['nn']['mean'])} min", size=14, color=MUTED, a=aa2)
    sl.add(4, goals)
    add_caption(sl, 4, "Nearest neighbour loses on goal 1 before we even look at wait.", until=5)
    add_caption(sl, 5, "Total wait = Σa − Σo, and Σo is fixed: lowering the average wait means arriving earlier overall.", size=17)
    return sl


# ---------- 1.4 reading the picture ----------
CH = Chart(label_rows={2: 1})


def slide_1_4_time_chart():
    sl = Slide("1.4", "time chart", "Point: one chart shows where and when; reused for the rest of the talk.")
    add_title(sl, "Reading the picture", "1.4")
    for d in (1.6, 1.2, 1.4, 1.8, 1.4):
        sl.click(d)
    sl.add(0, lambda ax, s, a: CH.axes(ax, a, grow=seg(s, .2, 1)))
    sl.add(0, lambda ax, s, a: text(ax, 13.0, 6.6, "position →\n(minutes of driving)", size=14, color=MUTED,
                                    a=a * seg(s, .5, 1)))
    sl.add(0, lambda ax, s, a: text(ax, 13.0, 5.4, "time ↓", size=14, color=MUTED, a=a * seg(s, .5, 1)))
    sl.add(1, lambda ax, s, a: CH.window(ax, 0, a, s=seg(s, 0, .8)))
    sl.add(1, lambda ax, s, a: text(ax, 13.0, 4.4, "dashed line = still fresh\namber tick = deadline", size=14,
                                    color=MUTED, a=a * seg(s, .5, 1)))
    ok_tr = [{"id": 0, "t": 9.0, "ok": True}]
    late_tr = [e for e in RUN["idOrder"]["trace"] if False]  # placeholder (not used)
    sl.add(2, lambda ax, s, a: (CH.path(ax, ok_tr, s=seg(s, 0, .7), a=a),
                                text(ax, CH.X(9) + .3, CH.Y(9) - .05, "on time", size=15, color=OK, a=a * seg(s, .7, 1))))
    # spoiled: via Ben first (13), then Amy at 13 + 22 = 35
    bad_tr = [{"id": 1, "t": 13.0, "ok": True}, {"id": 0, "t": 35.0, "ok": False}]
    sl.add(3, lambda ax, s, a: (CH.path(ax, bad_tr, s=seg(s, 0, .75), a=a, color=NN_COL, drive_all=True),
                                text(ax, CH.X(9) + .3, CH.Y(35), "spoiled", size=15, color=BAD,
                                     a=a * seg(s, .75, 1))), until=4)
    sl.add(4, lambda ax, s, a: CH.windows(ax, a * seg(s, 0, .3), s=seg(s, 0, .8), ids=[1, 2, 3, 4]))
    add_caption(sl, 4, "On time  ⇔  the path hits the line above the tick.")
    return sl


# ---------- 1.5 data ----------
def _kl_xy():
    r = C.KL["restaurant"]
    cx, cy, sc = 12.2, 4.35, 2.85 / 6.0
    out = []
    for p in C.KL["places"]:
        dx = (p["lon"] - r["lon"]) * 111.32 * math.cos(math.radians(r["lat"]))
        dy = (p["lat"] - r["lat"]) * 110.57
        out.append((cx + dx * sc, cy + dy * sc, p["name"]))
    return (cx, cy, sc), out


def slide_1_5_data():
    sl = Slide("1.5", "data", "Point: real Kuala Lumpur locations; everything added is documented.")
    add_title(sl, "The data", "1.5")
    for d in (1.8, 1.8, 1.6, 1.4):
        sl.click(d)
    bars = [(f"MY.txt: {C.KL['rows']:,} rows", 6.6), (f"Class P within 6 km of {C.KL['restaurant']['name']}: {C.KL['within6']}", 6.6),
            (f"Duplicate coordinates dropped: {len(C.KL['places'])} left", 5.0)]
    widths = [6.6, 5.2, 4.0]

    def funnel(ax, s, a):
        for i, (lbl, _) in enumerate(bars):
            f = seg(s, i * .25, i * .25 + .4)
            w = widths[i]
            y = 7.1 - i * .95
            box(ax, 4.0 - w / 2, y - .35, 4.0 + w / 2, y + .35, color=TEAL, a=a * f, fill="#123b38", fill_a=.9)
            text(ax, 4.0, y, lbl, size=14, ha="center", a=a * f)
    sl.add(0, funnel)
    (cx, cy, sc), pts = _kl_xy()

    def scatter(ax, s, a):
        aa = a * seg(s, 0, .5)
        ax.add_patch(Circle((cx, cy), 6 * sc, fc="none", ec=FAINT, lw=1.5, ls="--", alpha=aa))
        text(ax, cx, cy + 6 * sc + .25, "6 km", size=13, color=MUTED, ha="center", a=aa)
        for j, (x, y, _) in enumerate(pts):
            f = seg(s, .2 + .5 * j / len(pts), .3 + .5 * j / len(pts))
            ax.add_patch(Circle((x, y), .07, fc=TEAL, ec="none", alpha=a * f, zorder=5))
        ax.add_patch(Rectangle((cx - .12, cy - .12), .24, .24, fc=MUTED, ec="none", alpha=aa, zorder=6))
        text(ax, cx + .2, cy - .3, C.KL["restaurant"]["name"], size=12, color=MUTED, a=aa)
    sl.add(1, scatter)
    add_caption(sl, 1, "MY.txt has no restaurants, so a mall stands in.", until=2)
    tgt = [p for p in pts if p[2] == "Pudu"][0]
    tags = ["order time: within the last 10 min", "food: ice cream 30 · noodles 60 · rice 90", "travel = distance ÷ 20 km/h"]

    def tagfn(ax, s, a):
        for i, tg in enumerate(tags):
            f = seg(s, i * .25, i * .25 + .5)
            y = 3.6 - i * .7
            box(ax, .7, y - .27, 7.3, y + .27, color=AMBER, a=a * f, fill="#2a2110")
            text(ax, .95, y, tg, size=14, a=a * f)
            line(ax, [7.3, tgt[0]], [y, tgt[1]], color=AMBER, a=a * f * .6, lw=1)
        ax.add_patch(Circle((tgt[0], tgt[1]), .13, fc="none", ec=AMBER, lw=2, alpha=a * seg(s, 0, .3), zorder=7))
    sl.add(2, tagfn, until=3)
    add_caption(sl, 2, "MY.txt is never edited; additions live in the instance files.", until=3)
    ns = [5, 8, 10, 20, 50, 100]
    tights = [0.5, 1.0, 1.5]

    def grid(ax, s, a):
        aa = a * seg(s, 0, .5)
        text(ax, .7, 4.0, "Experiments", size=17, weight="bold", a=aa)
        text(ax, 1.7, 3.45, "n =", size=13, color=MUTED, a=aa, ha="right")
        for j, n in enumerate(ns):
            text(ax, 2.2 + j * .85, 3.45, str(n), size=13, ha="center", a=aa)
        for r, t in enumerate(tights):
            text(ax, 1.7, 2.8 - r * .6, f"×{t}", size=13, color=MUTED, ha="right", a=aa)
            for j in range(len(ns)):
                f = seg(s, .2 + (r * 6 + j) / 18 * .6, .3 + (r * 6 + j) / 18 * .6)
                box(ax, 1.85 + j * .85, 2.55 - r * .6, 2.55 + j * .85, 3.05 - r * .6, color=A_COL, a=a * f,
                    fill="#2a2245", r=.06)
                text(ax, 2.2 + j * .85, 2.8 - r * .6, "30", size=11, ha="center", a=a * f)
        text(ax, 7.4, 2.2, "shelf-life\ntightness ↓\n30 seeds\nper cell", size=12, color=MUTED, a=aa)
    sl.add(3, grid)
    return sl


def slide_1_6_question():
    sl = Slide("1.6", "question", "The question that sets up the two approaches.")
    add_title(sl, "The question", "1.6")
    sl.click(1.4)
    sl.click(1.4)
    sl.add(0, lambda ax, s, a: (CH.axes(ax, a * seg(s, 0, .5)), CH.windows(ax, a * seg(s, .2, .8))))
    add_caption(sl, 0, "In what order do we visit them, quickly, when deadlines conflict?")

    def two(ax, s, a):
        for j, (col, h, sub) in enumerate([(A_COL, "Approach A", "Plan everything,\nthen fix it"),
                                           (B_COL, "Approach B", "Decide one stop\nat a time")]):
            f = seg(s, j * .35, j * .35 + .6)
            y1 = 6.6 - j * 2.6
            box(ax, 12.9, y1 - 2.0, 15.6, y1, color=col, a=a * f, fill="#151a23", lw=2)
            text(ax, 13.15, y1 - .45, h, size=19, color=col, weight="bold", a=a * f)
            text(ax, 13.15, y1 - 1.25, sub, size=15, a=a * f, linespacing=1.3)
    sl.add(1, two)
    return sl


SLIDES = [slide_1_0_title, slide_1_0_section, slide_1_1_hook, slide_1_2_classic_tsp, slide_1_3_variant,
          slide_1_4_time_chart, slide_1_5_data, slide_1_6_question]
