"""Section 4: Wrap-up and appendix."""
from matplotlib.patches import Circle

from engine import Slide, seg, ease
from components import *
import config as C
import s1_problem as S1

RUN = C.RUN
N = len(C.NAMES)


def slide_4_0_section():
    sl = Slide("4.0", "section", "Section 4: wrap-up.")
    section_slide(sl, 4, "Wrap-up", "What we learned, and what's next")
    return sl


def slide_4_1_recap():
    sl = Slide("4.1", "recap", "Recap in one picture.")
    add_title(sl, "Recap", "4.1")
    sl.click(2.0)
    fa = [p for p in RUN["approachA"]["passes"] if not p.get("stop")][-1]
    arr = {e["id"]: (e["t"], e["ok"]) for e in fa["trace"]}

    def fn(ax, s, a):
        S1.ROAD.draw(ax, a * seg(s, 0, .3))
        S1.customers(ax, a * seg(s, 0, .4), t=99, arrivals=arr)
        text(ax, 8, 2.35, "Goals in order: most on time, then least wait", size=24, ha="center", weight="bold",
             a=a * seg(s, .4, .7))
        for j, (col, h, sub) in enumerate([(A_COL, "Approach A", "Plan first, then fix"),
                                           (B_COL, "Approach B", "Decide one stop at a time")]):
            x = 4.2 + j * 7.6
            f = seg(s, .55 + .15 * j, .8 + .15 * j)
            text(ax, x, 1.55, h, size=18, color=col, weight="bold", ha="center", a=a * f)
            text(ax, x, 1.05, sub, size=15, ha="center", a=a * f)
    sl.add(0, fn)
    return sl


def points_slide(sid, title, tag, items, note=""):
    sl = Slide(sid, title, note)
    add_title(sl, title, tag)
    for _ in items:
        sl.click(1.2)
    for k, (head, body, col) in enumerate(items):
        y = 6.7 - k * 1.85

        def fn(ax, s, a, y=y, head=head, body=body, col=col, k=k):
            aa = a * seg(s, 0, .6)
            line(ax, [1.0, 1.0], [y - 1.15, y + .3], color=col, a=aa, lw=4)
            text(ax, 1.4, y, head, size=22, weight="bold", a=aa)
            text(ax, 1.4, y - .65, body, size=16, color=MUTED, a=aa, va="top", linespacing=1.4)
        sl.add(k, fn)
    # dim previous points
    for k in range(1, len(items)):
        y = 6.7 - (k - 1) * 1.85

        def dimmer(ax, s, a, y=y):
            from matplotlib.patches import Rectangle
            ax.add_patch(Rectangle((.8, y - 1.4), 14.6, 1.95, fc="#0e1117", ec="none", alpha=.55 * a * seg(s, 0, .5),
                                   zorder=40))
        sl.add(k, dimmer, z=40)
    return sl


def slide_4_2_limits():
    return points_slide("4.2", "Limits and next steps", "4.2", [
        ("Static model", "No new orders mid-route, one rider, straight-line travel times, no time at the door.", NN_COL),
        ("Both approaches are local", "A stops at a plan no single move can improve.\nB never takes a choice back.", BAD),
        ("Next", "Try two-stop moves in A.  Start A from B's route instead of deadline order.\nAdd the V2 cap to both and rerun.", OK)])


def slide_4_3_x_factor():
    return points_slide("4.3", "What makes this stand out", "4.3", [
        ("A picture where ‘on time’ is visible", "Position across, time down: a path above the tick is on time.", PATH),
        ("A proof that cancelling is free", "Triangle inequality: once out of reach, out of reach forever.", A_COL),
        ("Exact answers to grade against", "All 120 orders checked by brute force; paired traps show where each approach fails.", BEST)])


def slide_4_4_ai_usage():
    sl = Slide("4.4", "AI usage", "Required by the brief, section 11.3. Fill in before presenting.")
    add_title(sl, "AI usage", "4.4")
    sl.click(1.2)
    sl.click(1.2)

    def c1(ax, s, a):
        aa = a * seg(s, 0, .6)
        rows = [("Tools", "[e.g. Claude: which model, when]"),
                ("Where", "[design brainstorming · code drafting · worked examples · slides]"),
                ("Our own work", "[problem choice · design decisions · verification · ...]")]
        for j, (k, v) in enumerate(rows):
            text(ax, 1.0, 7.1 - j * .75, k, size=18, weight="bold", a=aa)
            text(ax, 4.0, 7.1 - j * .75, v, size=17, color=MUTED, a=aa)
    sl.add(0, c1)

    def c2(ax, s, a):
        for j in range(3):
            f = seg(s, j * .25, j * .25 + .5)
            y = 4.4 - j * 1.2
            box(ax, 1.0, y - .45, 15.0, y + .45, color=FAINT, a=a * f, fill="#151a23")
            text(ax, 1.3, y, f"Prompt {j + 1}:  [paste a representative prompt]", size=16, color=MUTED, a=a * f)
    sl.add(1, c2)
    return sl


def slide_4_5_closing():
    sl = Slide("4.5", "closing", "Thank the audience; take questions. Appendix follows.")
    sl.click(1.4)

    def fn(ax, s, a):
        text(ax, 8, 5.3, "Thank you", size=64, weight="bold", ha="center", a=a * seg(s, 0, .5))
        text(ax, 8, 4.1, "Questions?", size=30, color=MUTED, ha="center", a=a * seg(s, .3, .8))
        for i, f in enumerate(["ice cream", "noodles", "rice"]):
            food_icon(ax, 7.0 + i, 2.6, f, sc=.8, a=a * seg(s, .5, 1))
            check(ax, 7.3 + i, 2.95, True, a=a * seg(s, .7, 1), r=.13)
    sl.add(0, fn)
    return sl


# ---------- appendix ----------
def slide_a_1_v2_example():
    sl = Slide("A.1", "V2 example", "Backup. Numbers are from the group template's worked example (n = 6, seed 10).")
    add_title(sl, "Backup: the V2 cap changes the route", "A.1")
    for d in (1.2, 1.2, 1.0):
        sl.click(d)
    rows = [("Best for V1", "1→2→5→4→6→3", "0", "29.0", "62.7 (Sentul)", NN_COL),
            ("Best for V2", "1→2→5→3→4→6", "0", "29.8", "55.2 (Taman Maluri)", A_COL)]

    def head(ax, s, a):
        aa = a * seg(s, 0, .5)
        for x, h in zip((.8, 4.0, 8.0, 10.2, 12.3), ("Solution", "Route", "Cancelled", "Avg wait", "Longest wait")):
            text(ax, x, 6.9, h, size=16, color=MUTED, weight="bold", a=aa)
        line(ax, [.7, 15.4], [6.5, 6.5], color=FAINT, a=aa, lw=1.2)
    sl.add(0, head)
    for r, row in enumerate(rows):
        def fn(ax, s, a, row=row, r=r):
            aa = a * seg(s, 0, .6)
            y = 5.8 - r * .9
            for x, v in zip((.8, 4.0, 8.0, 10.2, 12.3), row[:5]):
                text(ax, x, y, v, size=18, a=aa, color=row[5] if x == .8 else FG,
                     weight="bold" if x == .8 else "normal")
            if r == 1:
                text(ax, .8, 4.0, "V2 cuts Sentul's deadline from 84.7 to 54.7, so the rider goes there fourth.",
                     size=16, color=MUTED, a=aa)
        sl.add(r, fn)
    add_caption(sl, 2, "A fairness cap costs 0.8 min on the average.")
    return sl


def slide_a_2_passes():
    sl = Slide("A.2", "passes", "Backup. TODO: fill from the real runs.")
    add_title(sl, "Backup: how many passes does A need?", "A.2")
    sl.click(1.2)
    sl.click(1.0)
    from s3_evaluation import placeholder_panel
    sl.add(0, lambda ax, s, a: placeholder_panel(ax, a * seg(s, 0, .6), 2.0, 1.3, 14.0, 7.7, "Passes vs n",
                                                 "passes", "n = 5 … 100"))
    add_caption(sl, 1, "Passes grow with n and with looser deadlines; total time = passes × O(n³).")
    return sl


def slide_a_3_no_heap():
    sl = Slide("A.3", "no heap", "Backup: why B uses a linear scan, and why A only sorts once.")
    add_title(sl, "Backup: why B has no heap", "A.3")
    sl.click(2.4)
    sl.click(1.2)
    nodes = [(4.0, 6.6), (2.6, 5.2), (5.4, 5.2), (1.9, 3.8), (3.3, 3.8)]
    edges = [(0, 1), (0, 2), (1, 3), (1, 4)]
    before = [0, 0, 1, 2, 2]
    after = [2, 1, 0, 0, 1]

    def c1(ax, s, a):
        f = seg(s, .4, .7)
        for i, j in edges:
            line(ax, [nodes[i][0], nodes[j][0]], [nodes[i][1], nodes[j][1]], color=FAINT, a=a, lw=2)
        for k, (x, y) in enumerate(nodes):
            v = before[k] if f < .5 else after[k]
            col = B_COL if f < .5 else BAD
            ax.add_patch(Circle((x, y), .38, fc="#151a23", ec=col, lw=2, alpha=a, zorder=5))
            text(ax, x, y, str(v), size=18, ha="center", a=a, zorder=6)
        text(ax, 4.0, 7.45, "heap keyed on ‘lost’", size=15, color=MUTED, ha="center", a=a)
        text(ax, 4.0, 2.9, "after one move: every key changes" if f >= .5 else "", size=15, color=BAD, ha="center", a=a)
        text(ax, 7.6, 6.2, "Rebuild every step: O(n log n)", size=20, a=a * seg(s, .7, 1))
        text(ax, 7.6, 5.4, "Linear scan every step: O(n)", size=20, color=OK, a=a * seg(s, .8, 1))
    sl.add(0, c1)
    sl.add(1, lambda ax, s, a: text(ax, 7.6, 4.0, "A's deadlines are fixed,\nso sorting once is enough: O(n log n)",
                                    size=20, color=A_COL, a=a * seg(s, 0, .6), va="top"))
    return sl


def slide_a_4_data_limits():
    sl = Slide("A.4", "data limits", "Backup: limitations of the data.")
    add_title(sl, "Backup: data limitations", "A.4")
    sl.click(1.4)
    items = ["A mall stands in for the restaurant: MY.txt has no restaurant rows.",
             "Some coordinates are approximate: five villages share one point.",
             "Some points are not real customers: the city centre, the national palace, a park.",
             "Locations repeat above n = 33, so n = 50 and 100 are mainly speed tests."]

    def fn(ax, s, a):
        for j, it in enumerate(items):
            f = seg(s, j * .15, j * .15 + .4)
            ax.add_patch(Circle((1.1, 6.7 - j * 1.2), .08, fc=MUTED, ec="none", alpha=a * f))
            text(ax, 1.45, 6.7 - j * 1.2, it, size=19, a=a * f)
    sl.add(0, fn)
    return sl


SLIDES = [slide_4_0_section, slide_4_1_recap, slide_4_2_limits, slide_4_3_x_factor, slide_4_4_ai_usage,
          slide_4_5_closing, slide_a_1_v2_example, slide_a_2_passes, slide_a_3_no_heap, slide_a_4_data_limits]
