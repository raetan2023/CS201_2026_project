"""Section 2: the two approaches."""
import math

from matplotlib.patches import Circle, Polygon

from engine import Slide, seg, ease
from components import *
import config as C

RUN = C.RUN
N = len(C.NAMES)
AA = RUN["approachA"]
BB = RUN["approachB"]
CH = Chart(label_rows={2: 1})
CH2 = Chart(ytop=5.5, ybot=1.45, label_rows={2: 1}, x1=12.0)   # under the cards


def slide_2_0_section():
    sl = Slide("2.0", "section", "Section 2: the two approaches.")
    section_slide(sl, 2, "Two approaches", "Plan first, or decide as you go")
    return sl


# ---------- 2.1 dropping is free ----------
def slide_2_1_dropping_is_free():
    sl = Slide("2.1", "dropping is free", "Point: out of reach now means out of reach forever (triangle inequality).")
    add_title(sl, "One fact both approaches rely on", "2.1")
    for d in (1.6, 2.0, 2.2, 1.0):
        sl.click(d)
    c, v, x1, x2 = (2.6, 5.6), (13.2, 5.6), (6.0, 3.7), (9.8, 4.2)

    def pts(ax, a):
        for (x, y), lb, col in [(c, "rider at c, time t", PATH), (v, "order v", FG)]:
            ax.add_patch(Circle((x, y), .17, fc=col, ec="none", alpha=a, zorder=6))
            text(ax, x, y + .5, lb, size=17, ha="center", a=a)

    def c1(ax, s, a):
        pts(ax, a * seg(s, 0, .3))
        f = seg(s, .2, .7)
        line(ax, [c[0], c[0] + f * (v[0] - c[0])], [c[1], c[1]], color=FG, a=a, lw=2.5)
        text(ax, 7.9, 5.85, "w(c, v)", size=17, ha="center", color=MUTED, a=a * seg(s, .6, 1))
        text(ax, 8.0, 7.15, r"$t + w(c,v) > d_v$", size=28, ha="center", color=BAD, a=a * seg(s, .6, 1))
        text(ax, 8.0, 6.65, "can't make it even driving straight there", size=15, ha="center", color=MUTED,
             a=a * seg(s, .7, 1))
    sl.add(0, c1)

    def c2(ax, s, a):
        P = [c, x1, x2, v]
        for j in range(3):
            f = seg(s, j * .2, j * .2 + .25)
            if f <= 0:
                break
            (xa, ya), (xb, yb) = P[j], P[j + 1]
            line(ax, [xa, xa + f * (xb - xa)], [ya, ya + f * (yb - ya)], color=PATH, a=a, lw=2.5)
        for (x, y), lb in [(x1, "x₁"), (x2, "x₂")]:
            ax.add_patch(Circle((x, y), .12, fc=PATH, ec="none", alpha=a * seg(s, 0, .4), zorder=6))
            text(ax, x, y - .4, lb, size=16, ha="center", color=PATH, a=a * seg(s, 0, .4))
        d_dir = v[0] - c[0]
        d_det = sum(math.dist(P[j], P[j + 1]) for j in range(3))
        sc = 0.55
        fb = seg(s, .6, 1)
        text(ax, 1.0, 2.75, "direct", size=14, color=MUTED, a=a * fb)
        line(ax, [2.6, 2.6 + d_dir * sc * fb], [2.75, 2.75], color=FG, a=a, lw=10)
        text(ax, 1.0, 2.2, "detour", size=14, color=MUTED, a=a * fb)
        line(ax, [2.6, 2.6 + d_det * sc * fb], [2.2, 2.2], color=PATH, a=a, lw=10)
        text(ax, 2.6 + d_det * sc + .3, 2.2, "always ≥ direct  (triangle inequality)", size=14, color=MUTED, a=a * fb)
    sl.add(1, c2)
    parts = [r"$a_v = t + w(c,x_1) + \cdots + w(x_k,v)$", r"$\geq\ t + w(c,v)$", r"$>\ d_v$"]
    xs = [1.4, 6.55, 8.95]

    def c3(ax, s, a):
        for i, (p, x) in enumerate(zip(parts, xs)):
            text(ax, x, 1.35, p, size=24, a=a * seg(s, i * .3, i * .3 + .4), color=BAD if i == 2 else FG)
    sl.add(2, c3)
    add_caption(sl, 3, "Cancelling is free. If anything went wrong, it went wrong earlier.")
    return sl


# ---------- cards (2.2, 2.3) ----------
def slot_x(i):
    return 1.75 + i * 2.05


CARD_Y = 7.4


def walk_status(trace, upto=None):
    """id -> (ok, t) for the first `upto` entries of a plan's walk."""
    out = {}
    for j, e in enumerate(trace):
        if upto is not None and j >= upto:
            break
        out[e["id"]] = (e["ok"], e["t"])
    return out


def draw_cards(ax, a, xy, status=None, ghost=None, cursor=None):
    status = status or {}
    for i in range(N):
        x, y = xy[i]
        st = status.get(i)
        col = FAINT if st is None else (OK if st[0] else BAD)
        box(ax, x - .82, y - .33, x + .82, y + .33, color=col, a=a, fill="#151a23", lw=2.2 if st else 1.5, r=.1, z=8)
        text(ax, x - .62, y, C.NAMES[i], size=16, weight="bold", a=a, zorder=9)
        text(ax, x + .62, y, f"d {C.DL[i]:g}", size=13, color=MUTED, a=a, ha="right", zorder=9)
        if st is not None:
            text(ax, x, y - .62, f"{st[1]:g} {'✓' if st[0] else '✗ cancel'}", size=13, ha="center",
                 color=OK if st[0] else BAD, a=a, zorder=9)
    if cursor is not None:
        x = cursor
        ax.add_patch(Polygon([(x - .15, CARD_Y + .62), (x + .15, CARD_Y + .62), (x, CARD_Y + .42)], fc=PATH, ec="none",
                             alpha=a, zorder=10))


def plan_xy(plan):
    xy = {}
    for j, i in enumerate(plan):
        xy[i] = (slot_x(j), CARD_Y)
    return xy


def move_xy(p_from, p_to, f, lift=None):
    A, B = plan_xy(p_from), plan_xy(p_to)
    xy = {}
    for i in range(N):
        x = lerp(A[i][0], B[i][0], f)
        dy = 0.0
        if lift is None or lift == i:
            if abs(A[i][0] - B[i][0]) > 1e-6:
                dy = (0.75 if lift == i else 0.35) * math.sin(math.pi * f)
        xy[i] = (x, CARD_Y + dy)
    return xy


def walk_anim(ax, a, s, plan, trace, chart, color=PATH, s0=0.0, s1=1.0):
    """Cursor steps through the cards while the path draws."""
    f = seg(s, s0, s1)
    n = len(trace)
    upto = min(n, int(f * n + 1e-9) + (1 if f > 0 else 0)) if f < 1 else n
    st = walk_status(trace, upto)
    ok_n = sum(1 for e in trace[:upto] if e["ok"])
    tot_ok = sum(1 for e in trace if e["ok"])
    ps = 0 if tot_ok == 0 else min(1, ok_n / tot_ok) if f < 1 else 1
    chart.path(ax, trace, s=ps, a=a, color=color)
    cur = slot_x(min(upto, n) - 1) if 0 < f < 1 and upto > 0 else None
    return st, cur


def rules_legend(ax, a, y=2.6):
    ax.add_patch(Circle((13.05, y), .1, fc=OK, ec="none", alpha=a))
    text(ax, 13.3, y, "on time → drive there", size=13, a=a)
    ax.add_patch(Circle((13.05, y - .5), .1, fc="none", ec=BAD, lw=2, alpha=a))
    text(ax, 13.3, y - .5, "too late → cancel,\nstay put", size=13, a=a, va="top")


def slide_2_2_a_plan():
    sl = Slide("2.2", "A plan", "Point: A holds a complete plan and scores it by driving it.")
    add_title(sl, "Approach A: the plan", "2.2")
    for d in (1.4, 3.2, 3.6, 1.0):
        sl.click(d)
    idp, idt = RUN["idOrder"]["plan"], RUN["idOrder"]["trace"]
    sp, stt = AA["start"]["plan"], AA["start"]["trace"]

    def base(ax, a):
        CH2.axes(ax, a)
        CH2.windows(ax, a)

    sl.add(0, lambda ax, s, a: base(ax, a * seg(s, 0, .5)))
    sl.add(0, lambda ax, s, a: text(ax, 12.45, 7.4, "the plan =\nlist of all n customers", size=13, color=A_COL,
                                    a=a * seg(s, .5, 1)))

    def c1(ax, s, a):
        draw_cards(ax, a * seg(s, .2, .8), plan_xy(idp))
    sl.state(0, c1)
    add_caption(sl, 0, "Cancelled customers stay in the list.", until=1)

    def c2(ax, s, a):
        st, cur = walk_anim(ax, a, s, idp, idt, CH2, s0=.05, s1=.85)
        draw_cards(ax, a, plan_xy(idp), st, cursor=cur)
        rules_legend(ax, a * seg(s, 0, .2))
        fs = seg(s, .85, 1)
        scoreboard(ax, 12.9, 5.4, RUN["idOrder"]["delivered"], N, RUN["idOrder"]["mean"], a=a * fs)
    sl.state(1, c2)
    add_caption(sl, 1, "Score a plan by driving it.", until=2)

    def c3(ax, s, a):
        fm = seg(s, 0, .35)
        CH2.path(ax, idt, a=a * (1 - seg(s, 0, .25)))
        if s < .4:
            draw_cards(ax, a, move_xy(idp, sp, fm), walk_status(idt) if fm == 0 else None)
        else:
            st, cur = walk_anim(ax, a, s, sp, stt, CH2, s0=.42, s1=.92)
            draw_cards(ax, a, plan_xy(sp), st, cursor=cur)
        rules_legend(ax, a)
        f = seg(s, .9, 1)
        scoreboard(ax, 12.9, 5.4, RUN["idOrder"]["delivered"] if f < .5 else AA["start"]["delivered"], N,
                   lerp(RUN["idOrder"]["mean"], AA["start"]["mean"], f), a=a)
        text(ax, 6.9, 8.33, "Step 1: sort by deadline", size=17, color=A_COL, weight="bold", a=a * seg(s, 0, .2))
    sl.state(2, c3)

    def c4(ax, s, a):
        CH2.path(ax, stt, a=a)
        draw_cards(ax, a, plan_xy(sp), walk_status(stt))
        rules_legend(ax, a)
        scoreboard(ax, 12.9, 5.4, AA["start"]["delivered"], N, AA["start"]["mean"], a=a)
        text(ax, 6.9, 8.33, "Step 1: sort by deadline", size=17, color=A_COL, weight="bold", a=a)
    sl.state(3, c4, last=True)
    add_caption(sl, 3, "Sorting by urgency ignores the map: Cat is lost.")
    return sl


def slide_2_3_a_moves():
    sl = Slide("2.3", "A moves", "Point: keep making the single best move until no move helps.")
    add_title(sl, "Approach A: fixing the plan", "2.3")
    for d in (2.2, 4.0, 4.0, 2.0, 1.4):
        sl.click(d)
    passes = AA["passes"]
    plans = [AA["start"]["plan"]] + [p["plan"] for p in passes if not p.get("stop")]
    traces = [AA["start"]["trace"]] + [p["trace"] for p in passes if not p.get("stop")]
    scores = [(AA["start"]["delivered"], AA["start"]["mean"])] + [(p["delivered"], p["mean"]) for p in passes if not p.get("stop")]

    sl.add(0, lambda ax, s, a: (CH2.axes(ax, a), CH2.windows(ax, a)))

    def header(ax, a, k):
        mv = passes[k]["moved"]
        to = passes[k]["to"]
        where = "the end" if to == N - 1 else "the front" if to == 0 else f"position {to + 1}"
        text(ax, 6.9, 8.33, f"Best move: {C.NAMES[mv]} to {where}", size=17, color=A_COL, weight="bold", a=a)

    def counter(ax, a, k, f_tried, f_imp, done=False):
        p = passes[k]
        y = 2.9
        text(ax, 12.9, y, f"Pass {k + 1}", size=17, weight="bold", color=A_COL, a=a)
        text(ax, 12.9, y - .5, f"moves tried  {round(p['tried'] * f_tried)}", size=14, a=a)
        text(ax, 12.9, y - .95, f"improving    {round(p['improving'] * f_imp)}", size=14,
             color=OK if p["improving"] else MUTED, a=a)
        if done:
            text(ax, 12.9, y - 1.5, "No move helps: stop", size=16, weight="bold", color=OK, a=a)

    def c1(ax, s, a):
        CH2.path(ax, traces[0], a=a)
        draw_cards(ax, a, plan_xy(plans[0]), walk_status(traces[0]))
        scoreboard(ax, 12.9, 5.4, *scores[0][:1], N, scores[0][1], a=a)
        # ghost: Ben out and back
        f = seg(s, .1, .5) - seg(s, .55, .95)
        j0 = plans[0].index(1)
        x = lerp(slot_x(j0), slot_x(N - 1) + 0.0, f)
        box(ax, x - .82, CARD_Y + .9 * math.sin(math.pi * min(1, f)) * 0 + .95 - .33, x + .82, CARD_Y + .95 + .33,
            color=A_COL, a=a * min(1, f * 3) * .9, fill="#2a2245", r=.1, z=12)
        text(ax, x, CARD_Y + .95, C.NAMES[1], size=16, weight="bold", ha="center", a=a * min(1, f * 3), zorder=13)
    sl.state(0, c1)
    add_caption(sl, 0, "A move: take one card out, put it back somewhere else.", until=1)

    def pass_click(k):
        def fn(ax, s, a):
            fc = seg(s, .1, .3)
            fm = seg(s, .32, .6)
            if k > 0 and s < .1:
                counter(ax, a * (1 - seg(s, 0, .08)), k - 1, 1, 1)
                header(ax, a * (1 - seg(s, 0, .08)), k - 1)
            counter(ax, a * seg(s, .08, .14), k, fc, fc)
            if s < .6:
                CH2.path(ax, traces[k], a=a * (1 - seg(s, .32, .5)))
                draw_cards(ax, a, move_xy(plans[k], plans[k + 1], fm, lift=passes[k]["moved"]),
                           walk_status(traces[k]) if fm == 0 else None)
                d, m = scores[k]
            else:
                st, cur = walk_anim(ax, a, s, plans[k + 1], traces[k + 1], CH2, s0=.62, s1=.95)
                draw_cards(ax, a, plan_xy(plans[k + 1]), st, cursor=cur)
                ff = seg(s, .9, 1)
                d = scores[k + 1][0] if ff > .5 else scores[k][0]
                m = lerp(scores[k][1], scores[k + 1][1], ff)
            scoreboard(ax, 12.9, 5.4, d, N, m, a=a)
            header(ax, a * seg(s, .3, .4), k)
            if k == 1 and s > .95:
                pass
        return fn
    sl.state(1, pass_click(0))
    add_caption(sl, 1, f"Picks up {C.NAMES[2]} on the way back.", until=2)

    def p2(ax, s, a):
        pass_click(1)(ax, s, a)
        # pulse the short leg Cat -> Amy
        tr = traces[2]
        i0 = [e["id"] for e in tr].index(2)
        e0, e1 = tr[i0], tr[i0 + 1]
        f = seg(s, .9, 1)
        for e in (e0, e1):
            ax.add_patch(Circle((CH2.X(C.POS[e["id"]]), CH2.Y(e["t"])), .3, fc="none", ec=BEST, lw=2.5,
                                alpha=a * f, zorder=9))
    sl.state(2, p2)
    add_caption(sl, 2, f"{C.NAMES[2]} is on the way to {C.NAMES[0]}: 1 minute for {C.NAMES[0]}, 12 saved for {C.NAMES[2]}.", until=3)

    def done(ax, s, a, show_stop=True):
        CH2.path(ax, traces[-1], a=a)
        draw_cards(ax, a, plan_xy(plans[-1]), walk_status(traces[-1]))
        scoreboard(ax, 12.9, 5.4, scores[-1][0], N, scores[-1][1], a=a)
        k = len(passes) - 1
        if show_stop:
            tr = traces[-1]
            i0 = [e["id"] for e in tr].index(2)
            for e in (tr[i0], tr[i0 + 1]):
                ax.add_patch(Circle((CH2.X(C.POS[e["id"]]), CH2.Y(e["t"])), .3, fc="none", ec=BEST, lw=2.5,
                                    alpha=a * (1 - seg(s, 0, .15)), zorder=9))
        if show_stop and s < .1:
            counter(ax, a * (1 - seg(s, 0, .08)), k - 1, 1, 1)
            header(ax, a * (1 - seg(s, 0, .08)), k - 1)
        f = seg(s, .1, .6) if show_stop else 1
        counter(ax, a * (seg(s, .08, .14) if show_stop else 1), k, f, 0, done=f >= 1)
    sl.state(3, lambda ax, s, a: done(ax, s, a))
    sl.state(4, lambda ax, s, a: done(ax, 1, a), last=True)

    def code(ax, s, a):
        aa = a * seg(s, 0, .5)
        dim(ax, aa, .85)
        box(ax, 3.2, 2.0, 12.8, 7.4, color=A_COL, a=aa, fill="#151a23", lw=2, z=55)
        lines = ["plan ← customers sorted by deadline", "best ← walk(plan)", "repeat:",
                 "    for every move (take one out, put it back elsewhere):",
                 "        if walk(new plan) is better than best: remember it",
                 "    if no move was better: stop", "    plan ← the best new plan",
                 "better = more delivered, then lower average wait"]
        for i, ln in enumerate(lines):
            text(ax, 3.6, 6.85 - i * .58, ln, size=17, family="DejaVu Sans Mono", a=aa,
                 color=MUTED if i == len(lines) - 1 else FG, zorder=60)
    sl.add(4, code, z=50)
    add_caption(sl, 4, "Every accepted move strictly improves the plan, so it always stops.")
    return sl


# ---------- 2.4 / 2.5 Approach B ----------
STEPS = BB["steps"]
TR = BB["trace"]


def cand_arrows(ax, a, step, fade_except=None, chosen_a=1.0):
    t0 = step["t"]
    p0 = 0 if step["at"] < 0 else C.POS[step["at"]]
    x0, y0 = CH.X(p0), CH.Y(t0)
    for c in step["cands"]:
        i = c["id"]
        x1, y1 = CH.X(C.POS[i]), CH.Y(c["arr"])
        bad = c["lost"] > 0
        aa = a if fade_except is None or i == fade_except else a * 0.15
        arrow(ax, x0, y0, x1, y1, color=BAD if bad else B_COL, a=aa, lw=1.8, ls=(0, (4, 3)), head=.12)
        right = C.POS[i] >= p0 and i != 2
        text(ax, x1 + (.2 if right else -.2), y1 - .25, f"lost {c['lost']}", size=13, color=BAD if bad else B_COL,
             a=aa, ha="left" if right else "right", weight="bold")


def doom_flash(step, s_on):
    fl = {}
    for c in step["cands"]:
        for d in c["doom"]:
            fl[d] = max(fl.get(d, 0), s_on)
    return fl


def rider(ax, a, p, t):
    ax.add_patch(Circle((CH.X(p), CH.Y(t)), .16, fc=PATH, ec="white", lw=1.5, alpha=a, zorder=12))


def slide_2_4_b_idea():
    sl = Slide("2.4", "B idea", "Point: before each move, B asks how many other orders the move would doom.")
    add_title(sl, "Approach B: one stop at a time", "2.4")
    for d in (2.4, 3.0, 1.4):
        sl.click(d)
    st = STEPS[0]
    sl.add(0, lambda ax, s, a: CH.axes(ax, a * seg(s, 0, .3)))
    worst = [c for c in st["cands"] if c["lost"] == max(x["lost"] for x in st["cands"])][0]

    def cand_list(ax, a, s):
        text(ax, 12.9, 7.1, "At the restaurant, t = 0", size=15, weight="bold", a=a * seg(s, .1, .4))
        for j, c in enumerate(sorted(st["cands"], key=lambda c: (c["lost"], c["travel"]))):
            doom = ", ".join(C.NAMES[d] for d in c["doom"])
            text(ax, 12.9, 6.5 - j * .55, f"{C.NAMES[c['id']]}: lost {c['lost']}" + (f"  ({doom})" if doom else ""),
                 size=14, color=BAD if c["lost"] else FG, a=a * seg(s, .3 + .08 * j, .5 + .08 * j))

    def c1(ax, s, a):
        f = seg(s, .5, .8)
        CH.windows(ax, a, flash={d: f for d in worst["doom"]})
        rider(ax, a, 0, 0)
        cand_arrows(ax, a * seg(s, .1, .5), st)
        cand_list(ax, a, s)
    sl.state(0, c1)
    add_caption(sl, 0, f"Going to {C.NAMES[worst['id']]} first would doom both ice creams.", until=1)
    rules = ["reachable on time", "fewest lost", "shortest travel", "least slack", "lowest id"]

    def survivors():
        cs = st["cands"]
        out = [len(cs)]
        m = min(c["lost"] for c in cs)
        cs = [c for c in cs if c["lost"] == m]
        out.append(len(cs))
        m = min(c["travel"] for c in cs)
        cs = [c for c in cs if abs(c["travel"] - m) < 1e-9]
        out.append(len(cs))
        return out, cs[0]
    surv, win = survivors()

    def funnel(ax, s, a, fade=1.0):
        for i, r in enumerate(rules):
            y = 6.9 - i * .82
            f = seg(s, i * .12, i * .12 + .2)
            decided = i >= len(surv)
            col = MUTED if decided else B_COL
            w0 = 12.85 + i * .12
            box(ax, w0, y - .3, 15.75 - i * .12, y + .3, color=col, a=a * f * fade, fill="#151a23", r=.08)
            lbl = f"{i + 1}. {r}" + ("" if decided else f"  · {surv[i]} left")
            text(ax, w0 + .15, y, lbl, size=13, color=FG if not decided else MUTED, a=a * f * fade)
        text(ax, 12.9, 6.9 - 5 * .82 + .1, f"→ {C.NAMES[win['id']]}, {win['travel']:g} min", size=17, weight="bold",
             color=PATH, a=a * seg(s, .7, .9))

    def c2(ax, s, a):
        CH.windows(ax, a, flash={d: 1 - seg(s, 0, .3) for d in worst["doom"]})
        rider(ax, a, 0, 0)
        cand_arrows(ax, a, st, fade_except=win["id"] if s > .8 else None)
        CH.path(ax, [{"id": win["id"], "t": win["arr"], "ok": True}], s=seg(s, .8, 1), a=a)
        cand_list(ax, a * (1 - seg(s, 0, .12)), 1)
        funnel(ax, seg(s, .1, 1), a)
    sl.state(1, c2)

    def c3(ax, s, a):
        CH.windows(ax, a)
        rider(ax, a, 0, 0)
        cand_arrows(ax, a, st, fade_except=win["id"])
        CH.path(ax, [{"id": win["id"], "t": win["arr"], "ok": True}], a=a)
        funnel(ax, 1, a)
        aa = a * seg(s, 0, .6)
        for r, (lbl, vals) in enumerate([("visited[ ]", ["·"] * N), ("alive[ ]", ["✓"] * N)]):
            y = 1.95 - r * .55
            text(ax, 12.85, y, lbl, size=13, family="DejaVu Sans Mono", a=aa)
            for j, v in enumerate(vals):
                box(ax, 14.1 + j * .32, y - .14, 14.38 + j * .32, y + .14, color=B_COL, a=aa, r=.04)
                text(ax, 14.24 + j * .32, y, v, size=10, ha="center", a=aa)
    sl.state(2, c3, last=True)
    add_caption(sl, 2, "No heap: every score changes after every move.")
    return sl


def slide_2_5_b_run():
    sl = Slide("2.5", "B run", "Point: B never takes a choice back.")
    add_title(sl, "Approach B in action", "2.5")
    for d in (3.2, 3.0, 2.2, 1.0):
        sl.click(d)
    sl.add(0, lambda ax, s, a: (CH.axes(ax, a), CH.windows(ax, a)))

    def upto(m):
        return TR[:m]

    def seg_path(ax, a, m0, m1, s):
        CH.path(ax, upto(m0), a=a)
        if m1 > m0:
            st = TR[m0 - 1]
            CH.path(ax, TR[m0:m1], s=s, a=a, start=(C.POS[st["id"]], st["t"]))

    st2 = STEPS[1]

    def step2_list(ax, a, s):
        text(ax, 12.9, 7.1, f"At {C.NAMES[st2['at']]}, t = {st2['t']:g}", size=15, weight="bold", a=a * seg(s, 0, .15))
        for j, c in enumerate(sorted(st2["cands"], key=lambda c: (c["lost"], c["travel"]))):
            doom = ", ".join(C.NAMES[d] for d in c["doom"])
            mark = "  ✓" if c["id"] == st2["chosen"] else ""
            text(ax, 12.9, 6.5 - j * .55, f"{C.NAMES[c['id']]}: lost {c['lost']}, {c['travel']:g} min{mark}" +
                 (f"\n   dooms {doom}" if doom else ""), size=13, color=BAD if c["lost"] else (PATH if mark else FG),
                 a=a * seg(s, .2 + .1 * j, .4 + .1 * j), va="top")

    def c1(ax, s, a):
        seg_path(ax, a, 1, 2, seg(s, .75, 1))
        cand_arrows(ax, a * seg(s, 0, .3), st2, fade_except=st2["chosen"] if s > .7 else None)
        step2_list(ax, a, s)
    sl.state(0, c1)

    def c2_lines(ax, a, s):
        s3, s4 = STEPS[2], STEPS[3]
        lines = [f"At {C.NAMES[s3['at']]}, t = {s3['t']:g}: {C.NAMES[s3['chosen']]} is "
                 f"{[c for c in s3['cands'] if c['id'] == s3['chosen']][0]['travel']:g} min away",
                 f"At {C.NAMES[s4['at']]}, t = {s4['t']:g}: {C.NAMES[s4['chosen']]};",
                 f"   {C.NAMES[1]} first would doom {C.NAMES[4]}"]
        for j, ln in enumerate(lines):
            text(ax, 12.9, 7.0 - j * .5, ln, size=13, a=a * seg(s, .1 + .2 * j, .3 + .2 * j))

    def c2(ax, s, a):
        fo = 1 - seg(s, 0, .12)
        cand_arrows(ax, a * fo, st2, fade_except=st2["chosen"])
        step2_list(ax, a * fo, 1)
        seg_path(ax, a, 2, 4, seg(s, .1, .9))
        c2_lines(ax, a * seg(s, .1, .2), s)
    sl.state(1, c2)

    def c3(ax, s, a):
        c2_lines(ax, a * (1 - seg(s, 0, .15)), 1)
        seg_path(ax, a, 4, 5, seg(s, 0, .7))
        scoreboard(ax, 12.9, 6.6, len(TR), N, BB["mean"], a=a * seg(s, .7, 1), title="Approach B", color=B_COL)
    sl.state(2, c3)
    sl.state(3, lambda ax, s, a: (seg_path(ax, a, 5, 5, 1),
                                  scoreboard(ax, 12.9, 6.6, len(TR), N, BB["mean"], a=a, title="Approach B", color=B_COL)),
             last=True)
    add_caption(sl, 3, "No food spoils, but rice first sent the rider the wrong way, and B never takes a choice back.")
    return sl


SLIDES = [slide_2_0_section, slide_2_1_dropping_is_free, slide_2_2_a_plan, slide_2_3_a_moves, slide_2_4_b_idea,
          slide_2_5_b_run]
