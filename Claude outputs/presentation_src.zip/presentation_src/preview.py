"""Contact sheet of the last frame (and optionally mid frame) of every click.
Usage: python3 preview.py s1 [mid]"""
import importlib
import sys

sys.path.insert(0, "/home/claude/deck")
sys.path.insert(0, "/home/claude/deck/scenes")
import matplotlib.pyplot as plt
from engine import new_fig, reset, BG

mod = importlib.import_module({"s1": "s1_problem", "s2": "s2_approaches", "s3": "s3_evaluation",
                               "s4": "s4_wrapup"}[sys.argv[1]])
mid = len(sys.argv) > 2 and sys.argv[2] == "mid"
only = sys.argv[3] if len(sys.argv) > 3 else None
for f in mod.SLIDES:
    sl = f()
    if only and sl.sid != only:
        continue
    for k in range(len(sl.durs)):
        for s, tag in ([(0.5, "m")] if mid else []) + [(1.0, "e")]:
            fig, ax = new_fig()
            reset(ax)
            sl.draw(ax, k, s)
            fig.savefig(f"/tmp/prev/{sl.sid}_{k+1}{tag}.png", facecolor=BG, dpi=40)
            plt.close(fig)
print("ok")
