"""Every number on screen comes from here. solver_out.json is produced by
ExportConfig.java from the Java solvers; kl.json from data/raw/MY.txt.

Deck naming: Approach A = plan first, then fix (code: SolverB),
             Approach B = one stop at a time (code: SolverA).
"""
import json
import os

_D = os.path.join(os.path.dirname(__file__), "data")
SOLVER = json.load(open(os.path.join(_D, "solver_out.json")))
KL = json.load(open(os.path.join(_D, "kl.json")))

RUN = SOLVER["running"]
PQR = SOLVER["pqr"]
STUV = SOLVER["stuv"]

CUST = RUN["customers"]
NAMES = [c["name"] for c in CUST]
POS = [c["pos"] for c in CUST]
DL = [c["deadline"] for c in CUST]
FOOD = [c["food"] for c in CUST]

TMAX = 90


def fmt(x, nd=1):
    """1 decimal unless the value has more meaningful digits (27.75)."""
    if abs(x * 10 - round(x * 10)) > 1e-6:
        return f"{x:.2f}"
    return f"{x:.{nd}f}"


def tmin(x):
    return f"{x:g}"
